﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace labsystem
{
    /// <summary>
    /// Логика взаимодействия для BarcodeWindow.xaml
    /// </summary>
    public partial class BarcodeWindow : Window
    {
        private readonly string barcode;

        public BarcodeWindow(string barcode)
        {
            InitializeComponent();
            this.barcode = barcode;
            txtBarcode.Text = barcode;
            DrawBarcode();
        }

        private void DrawBarcode()
        {
            barcodeCanvas.Children.Clear();
            double left = 10;
            double height = 40;
            double widthMultiplier = 2;

            foreach (char c in barcode)
            {
                if (char.IsDigit(c))
                {
                    int digit = int.Parse(c.ToString());
                    double width = digit * widthMultiplier;

                    var rect = new Rectangle
                    {
                        Width = width,
                        Height = height,
                        Fill = Brushes.Black,
                        Margin = new Thickness(left, 0, 0, 0)
                    };
                    barcodeCanvas.Children.Add(rect);
                    left += width + 2;
                }
            }
        }

        private void SaveToPdf_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show($"Штрих-код {barcode} сохранен в PDF", "Сохранение", MessageBoxButton.OK);
            DialogResult = true;
            Close();
        }
    }
}
