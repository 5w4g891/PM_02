﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace labsystem
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private int failedAttempts = 0;
        private string currentCaptcha;
        private DateTime? blockEndTime;
        private DispatcherTimer blockTimer;

        public MainWindow()
        {
            InitializeComponent();
            InitializeBlockTimer();
            UpdateUI();
        }

        private void InitializeBlockTimer()
        {
            blockTimer = new DispatcherTimer();
            blockTimer.Interval = TimeSpan.FromSeconds(1);
            blockTimer.Tick += BlockTimer_Tick;
            blockTimer.Start();
        }

        private void BlockTimer_Tick(object sender, EventArgs e)
        {
            if (blockEndTime.HasValue && DateTime.Now >= blockEndTime)
            {
                blockEndTime = null;
                failedAttempts = 0;
                UpdateUI();
            }
            else if (blockEndTime.HasValue)
            {
                txtBlockTime.Text = $"До разблокировки осталось: {(blockEndTime.Value - DateTime.Now):mm\\:ss}";
            }
        }

        private void UpdateUI()
        {
            captchaPanel.Visibility = failedAttempts >= 2 ? Visibility.Visible : Visibility.Collapsed;
            blockPanel.Visibility = blockEndTime.HasValue ? Visibility.Visible : Visibility.Collapsed;
            btnLogin.IsEnabled = !blockEndTime.HasValue;
            txtAttemptsInfo.Text = failedAttempts > 0 ? $"Неудачных попыток: {failedAttempts}" : "";

            if (captchaPanel.Visibility == Visibility.Visible && string.IsNullOrEmpty(currentCaptcha))
            {
                GenerateCaptcha();
            }
        }

        private void GenerateCaptcha()
        {
            const string chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
            var random = new Random();
            currentCaptcha = new string(Enumerable.Repeat(chars, 5)
                .Select(s => s[random.Next(s.Length)]).ToArray());

            txtCaptchaText.Text = currentCaptcha;
            txtCaptcha.Text = "";
        }

        private void BtnRefreshCaptcha_Click(object sender, RoutedEventArgs e)
        {
            GenerateCaptcha();
        }
        public void BlockSystem()
        {
            blockPanel.Visibility = Visibility.Visible;
            blockEndTime = DateTime.Now.AddMinutes(1); // Блокировка на 1 минуту (для теста)
            blockTimer.Start();
        }

        private void BtnLogin_Click(object sender, RoutedEventArgs e)
        {
            txtError.Text = "";

            if (blockEndTime.HasValue)
            {
                txtError.Text = $"Система заблокирована до {blockEndTime.Value:HH:mm:ss}";
                return;
            }

            if (failedAttempts >= 2 && txtCaptcha.Text != currentCaptcha)
            {
                txtError.Text = "Неверная CAPTCHA";
                GenerateCaptcha();
                return;
            }

            var user = Database.AuthenticateUser(txtUsername.Text, txtPassword.Password);
            if (user == null)
            {
                failedAttempts++;

                if (failedAttempts >= 3)
                {
                    blockEndTime = DateTime.Now.AddMinutes(5);
                    txtError.Text = "Слишком много неудачных попыток. Система заблокирована на 5 минут.";
                }
                else
                {
                    txtError.Text = "Неверный логин или пароль";
                }

                UpdateUI();
                return;
            }

            failedAttempts = 0;
            currentCaptcha = null;

            var mainWindow = new MainSystemWindow(user);
            mainWindow.Show();
            this.Close();
        }

        protected override void OnClosed(EventArgs e)
        {
            blockTimer.Stop();
            base.OnClosed(e);
        }
    }
}
