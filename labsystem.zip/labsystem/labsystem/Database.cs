﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace labsystem
{
    public static class Database
    {
        private static List<User> users = new List<User>
        {
            new User {
                Username = "lab1",
                Password = "lab1",
                FirstName = "Иван",
                LastName = "Петров",
                Photo = "/Resources/laborant_1.jpeg",
                Role = UserRole.LabAssistant
            },
            new User {
                Username = "admin",
                Password = "admin",
                FirstName = "Алексей",
                LastName = "Смирнов",
                Photo = "/Resources/Администратор.png",
                Role = UserRole.Administrator
            },
             
        };

        private static List<Order> orders = new List<Order>();
        private static List<Patient> patients = new List<Patient>();
        private static List<Service> services = new List<Service>
        {
            new Service { Id = "1", Name = "Общий анализ крови", Code = "OAK", Price = 500 },
            new Service { Id = "2", Name = "Биохимический анализ крови", Code = "BAK", Price = 1200 }
        };

        private static Dictionary<string, UserLoginAttempt> loginAttempts = new Dictionary<string, UserLoginAttempt>();

        public static User AuthenticateUser(string username, string password)
        {
            if (loginAttempts.TryGetValue(username, out var attempt) &&
                attempt.IsBlocked &&
                DateTime.Now < attempt.BlockEndTime)
            {
                return null;
            }

            var user = users.FirstOrDefault(u => u.Username == username && u.Password == password);

            if (user == null)
            {
                if (!loginAttempts.ContainsKey(username))
                {
                    loginAttempts[username] = new UserLoginAttempt();
                }

                loginAttempts[username].FailedAttempts++;
                loginAttempts[username].LastAttempt = DateTime.Now;

                if (loginAttempts[username].FailedAttempts >= 3)
                {
                    loginAttempts[username].IsBlocked = true;
                    loginAttempts[username].BlockEndTime = DateTime.Now.AddMinutes(5);
                }

                return null;
            }

            loginAttempts[username] = new UserLoginAttempt();
            return user;
        }

        public static List<User> GetAllUsers() => users.ToList();

        public static void AddUser(User user) => users.Add(user);

        public static void DeleteUser(string username) => users.RemoveAll(u => u.Username == username);

        public static List<Order> GetOrders(DateTime fromDate, DateTime toDate, string username = null)
        {
            // В реальном приложении здесь будет запрос к базе данных
            var orders = new List<Order>();

            // Заглушка с тестовыми данными
            var random = new Random();
            var users = GetAllUsers()
                .Where(u => u.Role == UserRole.LabAssistant || u.Role == UserRole.ResearchAssistant)
                .ToList();

            var patients = new List<Patient>
    {
        new Patient { FirstName = "Иван", LastName = "Иванов", InsuranceCompany = "Страховая 1" },
        new Patient { FirstName = "Мария", LastName = "Петрова", InsuranceCompany = "Страховая 2" }
    };

            for (int i = 0; i < 50; i++)
            {
                var orderDate = fromDate.AddDays(random.Next(0, (toDate - fromDate).Days));
                var user = users[random.Next(users.Count)];

                orders.Add(new Order
                {
                    CreatedDate = orderDate,
                    TubeCode = $"T-{1000 + i}",
                    Patient = patients[random.Next(patients.Count)],
                    UserId = user.Username,
                    Services = new List<Service> {
                new Service { Price = random.Next(500, 5000) }
            },
                    IsPaid = random.Next(0, 2) == 1 // Случайная оплата
                });
            }

            if (!string.IsNullOrEmpty(username))
            {
                orders = orders.Where(o => o.UserId == username).ToList();
            }

            return orders;
        }
        public static Order CreateOrder(string tubeCode, Patient patient, List<Service> selectedServices, string userId)
        {
            var order = new Order
            {
                TubeCode = tubeCode,
                Patient = patient,
                Services = selectedServices,
                Barcode = GenerateBarcode(),
                UserId = userId
            };

            orders.Add(order);
            return order;
        }

        public static string GenerateBarcode()
        {
            var random = new Random();
            var datePart = DateTime.Now.ToString("ddMMyyyy");
            var randomPart = string.Join("", Enumerable.Range(0, 6).Select(_ => random.Next(0, 10)));
            return $"{datePart}{randomPart}";
        }

        public static void AddPatient(Patient patient) => patients.Add(patient);

        public static List<Patient> SearchPatients(string query)
        {
            if (string.IsNullOrWhiteSpace(query))
                return patients.ToList();

            return patients
                .Where(p => (p.LastName + " " + p.FirstName + " " + p.MiddleName).ToLower().Contains(query.ToLower()) ||
                            p.InsurancePolicyNumber.ToLower().Contains(query.ToLower()))
                .ToList();
        }

        public static List<Service> SearchServices(string query)
        {
            if (string.IsNullOrWhiteSpace(query))
                return services.ToList();

            return services
                .Where(s => s.Name.ToLower().Contains(query.ToLower()) ||
                            s.Code.ToLower().Contains(query.ToLower()))
                .ToList();
        }

        private class UserLoginAttempt
        {
            public int FailedAttempts { get; set; }
            public DateTime LastAttempt { get; set; }
            public bool IsBlocked { get; set; }
            public DateTime BlockEndTime { get; set; }
        }
    }
}
