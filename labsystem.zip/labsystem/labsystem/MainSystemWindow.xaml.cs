﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;
using WpfApp2;

namespace labsystem
{
    /// <summary>
    /// Логика взаимодействия для MainSystemWindow.xaml
    /// </summary>
    public partial class MainSystemWindow : Window
    {
        private DispatcherTimer sessionTimer;
        private DateTime sessionEndTime;
        private User currentUser;
        private bool isTimerVisible;
        public MainSystemWindow(User user)
        {
            InitializeComponent();
            currentUser = user;
            DataContext = this;

            // Показываем таймер только для лаборантов
            isTimerVisible = user.Role == UserRole.LabAssistant || user.Role == UserRole.ResearchAssistant;

            // Устанавливаем время сеанса (10 минут для теста)
            sessionEndTime = DateTime.Now.AddMinutes(10);

            // Настраиваем таймер сеанса
            sessionTimer = new DispatcherTimer();
            sessionTimer.Interval = TimeSpan.FromSeconds(1);
            sessionTimer.Tick += SessionTimer_Tick;
            sessionTimer.Start();

            // Настраиваем интерфейс в зависимости от роли
            SetupUIForRole();
        }

        // Свойства для привязки данных
        public User User => currentUser;
        public bool IsTimerVisible => isTimerVisible;

        // Настройка интерфейса по роли пользователя
        private void SetupUIForRole()
        {
            mainTabControl.Items.Clear();

            switch (currentUser.Role)
            {
                case UserRole.LabAssistant:
                    AddTab("Прием биоматериала", new LabAssistantReceiveView());
                    AddTab("Мои отчеты", new ReportsView(currentUser));
                    break;

                case UserRole.ResearchAssistant:
                    AddTab("Анализатор", new AnalyzerView());
                    AddTab("Мои отчеты", new ReportsView(currentUser));
                    break;

                case UserRole.Accountant:
                    AddTab("Финансовые отчеты", new ReportsView(currentUser));
                    AddTab("Счета страховым", new InsuranceInvoicesView());
                    break;

                case UserRole.Administrator:
                    AddTab("Прием биоматериала", new LabAssistantReceiveView());
                    AddTab("Все отчеты", new ReportsView(currentUser));
                    AddTab("Пользователи", new UsersView());
                    AddTab("Расходные материалы", new SuppliesView());
                    break;
            }
        }

        private void AddTab(string header, UIElement content)
        {
            var tabItem = new TabItem
            {
                Header = header,
                Content = content
            };
            mainTabControl.Items.Add(tabItem);
        }


        // Обновление таймера сеанса
        private void SessionTimer_Tick(object sender, EventArgs e)
        {
            TimeSpan remainingTime = sessionEndTime - DateTime.Now;

            // Обновляем отображение времени
            txtSessionTime.Text = $"Сеанс: {remainingTime:mm\\:ss}";

            // Показываем уведомление за 5 минут до конца
            if (remainingTime.TotalMinutes <= 5 && notificationPanel.Visibility != Visibility.Visible)
            {
                notificationPanel.Visibility = Visibility.Visible;
            }

            // Завершаем сеанс по истечении времени
            if (remainingTime.TotalSeconds <= 0)
            {
                sessionTimer.Stop();
                Logout(true);
            }
        }

        // Обработчик кнопки выхода
        private void btnLogout_Click(object sender, RoutedEventArgs e)
        {
            Logout(false);
        }

        // Выход из системы
        private void Logout(bool sessionExpired)
        {
            sessionTimer.Stop();

            if (sessionExpired)
            {
                // Блокируем систему на 1 минуту (для теста)
                var loginWindow = new MainWindow();
                loginWindow.Show();
                loginWindow.BlockSystem();
            }
            else
            {
                // Просто возвращаемся на окно входа
                var loginWindow = new MainWindow();
                loginWindow.Show();
            }

            this.Close();
        }
    }
}

