﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace labsystem
{
    public static class PdfGenerator
    {
        public static void GenerateOrderPdf(Order order)
        {
            // В реальном приложении здесь будет код для генерации PDF
            string fileName = $"Order_{order.OrderId}_{DateTime.Now:yyyyMMddHHmmss}.pdf";

            // Сохраняем информацию о заказе в формате Base64
            string orderData = $"дата_заказа={order.CreatedDate:yyyy-MM-ddTHH:mm:ss}&номер_заказа={order.OrderId}";
            string base64Data = Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes(orderData));
            string link = $"https://wsrussia.ru/?data={base64Data}";

            System.IO.File.WriteAllText(fileName.Replace(".pdf", ".txt"), link);

            Console.WriteLine($"PDF generated: {fileName}");
            Console.WriteLine($"Link saved: {link}");
        }
    }
}
