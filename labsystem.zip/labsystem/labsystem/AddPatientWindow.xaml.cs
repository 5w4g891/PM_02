﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace labsystem
{
    /// <summary>
    /// Логика взаимодействия для AddPatientWindow.xaml
    /// </summary>
    public partial class AddPatientWindow : Window
    {
        public Patient NewPatient { get; private set; }

        public AddPatientWindow()
        {
            InitializeComponent();
            dpBirthDate.SelectedDate = DateTime.Now.AddYears(-30);
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtLastName.Text) ||
                string.IsNullOrWhiteSpace(txtFirstName.Text) ||
                string.IsNullOrWhiteSpace(txtPassport.Text))
            {
                MessageBox.Show("Заполните обязательные поля: Фамилия, Имя, Паспорт");
                return;
            }

            var passportParts = txtPassport.Text.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            if (passportParts.Length != 2 || passportParts[0].Length != 4 || passportParts[1].Length != 6)
            {
                MessageBox.Show("Введите серию и номер паспорта в формате: 1234 567890");
                return;
            }

            NewPatient = new Patient
            {
                LastName = txtLastName.Text,
                FirstName = txtFirstName.Text,
                MiddleName = txtMiddleName.Text,
                BirthDate = dpBirthDate.SelectedDate ?? DateTime.Now,
                PassportSeries = passportParts[0],
                PassportNumber = passportParts[1],
                Phone = txtPhone.Text,
                InsurancePolicyNumber = txtInsurancePolicy.Text
            };

            DialogResult = true;
            Close();
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }
}
