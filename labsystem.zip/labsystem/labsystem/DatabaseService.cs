﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace labsystem
{
    public static class DatabaseService
    {
        private static List<Order> orders = new List<Order>();
        private static List<Patient> patients = new List<Patient>
{
    new Patient {
        Id = "1",
        LastName = "Иванов",
        FirstName = "Иван",
        MiddleName = "Иванович",
        BirthDate = new DateTime(1980, 5, 15),
        PassportSeries = "1234",
        PassportNumber = "567890",
        Phone = "+79001234567",
        InsurancePolicyNumber = "987654321"
    },
    new Patient {
        Id = "2",
        LastName = "Петрова",
        FirstName = "Мария",
        MiddleName = "Сергеевна",
        BirthDate = new DateTime(1990, 10, 22),
        PassportSeries = "4321",
        PassportNumber = "098765",
        Phone = "+79007654321",
        InsurancePolicyNumber = "123456789"
    }
};
        public static List<Patient> SearchPatients(string query)
        {
            if (string.IsNullOrWhiteSpace(query))
                return new List<Patient>();

            query = query.ToLower();
            return patients
                .Where(p =>
                    p.LastName.ToLower().Contains(query) ||
                    p.FirstName.ToLower().Contains(query) ||
                    p.MiddleName.ToLower().Contains(query) ||
                    CalculateLevenshteinDistance(p.FullName.ToLower(), query) <= 3 ||
                    p.InsurancePolicyNumber.ToLower().Contains(query) ||
                    p.PassportSeries.ToLower().Contains(query) ||
                    p.PassportNumber.ToLower().Contains(query))
                .ToList();
        }
        private static List<Service> services = new List<Service>
        {
            new Service { Id = "1", Name = "Общий анализ крови", Code = "OAK", Price = 500 },
            new Service { Id = "2", Name = "Биохимический анализ крови", Code = "BAK", Price = 1200 },
            new Service { Id = "3", Name = "Анализ мочи", Code = "AM", Price = 400 },
            new Service { Id = "4", Name = "Гормональные исследования", Code = "GI", Price = 1500 }
        };
        public static List<Service> SearchServices(string query)
        {
            if (string.IsNullOrWhiteSpace(query))
                return new List<Service>();

            query = query.ToLower();
            return services
                .Where(s =>
                    s.Name.ToLower().Contains(query) ||
                    s.Code.ToLower().Contains(query) ||
                    CalculateLevenshteinDistance(s.Name.ToLower(), query) <= 3)
                .ToList();
        }

        // Методы для работы с заказами
        public static Order CreateOrder(string tubeCode, Patient patient, List<Service> selectedServices)
        {
            var order = new Order
            {
                OrderId = Guid.NewGuid().ToString(),
                CreatedDate = DateTime.Now,
                TubeCode = tubeCode,
                Patient = patient,
                Services = selectedServices,
                Barcode = GenerateBarcode()
            };

            orders.Add(order);
            return order;
        }

        public static string GenerateBarcode()
        {
            var random = new Random();
            var datePart = DateTime.Now.ToString("ddMMyyyy");
            var randomPart = string.Join("", Enumerable.Range(0, 6).Select(_ => random.Next(0, 10)));
            return $"{datePart}{randomPart}";
        }

        public static Order GetLastOrder()
        {
            return orders.OrderByDescending(o => o.CreatedDate).FirstOrDefault();
        }

        public static bool IsTubeCodeExists(string tubeCode)
        {
            return orders.Any(o => o.TubeCode == tubeCode && !o.IsArchived);
        }

        // Методы для работы с пациентами
        public static void AddPatient(Patient patient)
        {
            patient.Id = Guid.NewGuid().ToString();
            patients.Add(patient);
        }


        // Алгоритм Левенштейна для нечеткого поиска
        public static int CalculateLevenshteinDistance(string a, string b)
        {
            if (string.IsNullOrEmpty(a)) return string.IsNullOrEmpty(b) ? 0 : b.Length;
            if (string.IsNullOrEmpty(b)) return a.Length;

            int lengthA = a.Length;
            int lengthB = b.Length;
            var distances = new int[lengthA + 1, lengthB + 1];

            for (int i = 0; i <= lengthA; distances[i, 0] = i++) ;
            for (int j = 0; j <= lengthB; distances[0, j] = j++) ;

            for (int i = 1; i <= lengthA; i++)
                for (int j = 1; j <= lengthB; j++)
                {
                    int cost = b[j - 1] == a[i - 1] ? 0 : 1;
                    distances[i, j] = Math.Min(
                        Math.Min(distances[i - 1, j] + 1, distances[i, j - 1] + 1),
                        distances[i - 1, j - 1] + cost);
                }

            return distances[lengthA, lengthB];
        }
    }
}
