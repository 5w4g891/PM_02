﻿using labsystem;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Text.RegularExpressions;

namespace WpfApp2
{
    public class LabAssistantReceiveView : UserControl
    {
        private TextBox txtTubeCode;
        private ListBox lstServices;
        private TextBox txtPatientSearch;
        private TextBox txtServiceSearch;
        private ListBox lstPatientResults;
        private ListBox lstServiceResults;
        private List<Service> selectedServices = new List<Service>();
        private Patient selectedPatient;

        public LabAssistantReceiveView()
        {
            var grid = new Grid();
            grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
            grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });

            // Код пробирки
            var tubePanel = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(5) };
            tubePanel.Children.Add(new Label { Content = "Код пробирки:", VerticalAlignment = VerticalAlignment.Center });

            txtTubeCode = new TextBox { Width = 200, Margin = new Thickness(5) };
            txtTubeCode.Text = GetNextTubeCode();
            tubePanel.Children.Add(txtTubeCode);

            var btnBarcode = new Button { Content = "Штрих-код", Margin = new Thickness(5) };
            btnBarcode.Click += (s, e) => GenerateBarcode();
            tubePanel.Children.Add(btnBarcode);

            grid.Children.Add(tubePanel);

            // Поиск пациента
            var patientPanel = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(5) };
            patientPanel.Children.Add(new Label { Content = "Пациент:", VerticalAlignment = VerticalAlignment.Center });

            txtPatientSearch = new TextBox { Width = 200, Margin = new Thickness(5) };
            txtPatientSearch.TextChanged += (s, e) => SearchPatients();
            patientPanel.Children.Add(txtPatientSearch);

            var btnAddPatient = new Button { Content = "Добавить", Margin = new Thickness(5) };
            btnAddPatient.Click += (s, e) => AddNewPatient();
            patientPanel.Children.Add(btnAddPatient);

            grid.Children.Add(patientPanel);
            patientPanel.SetValue(Grid.RowProperty, 1);

            // Результаты поиска пациентов
            lstPatientResults = new ListBox { MaxHeight = 100, Margin = new Thickness(5), Visibility = Visibility.Collapsed };
            lstPatientResults.SelectionChanged += (s, e) => SelectPatient();
            grid.Children.Add(lstPatientResults);
            lstPatientResults.SetValue(Grid.RowProperty, 2);

            // Поиск услуг
            var servicePanel = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(5) };
            servicePanel.Children.Add(new Label { Content = "Услуги:", VerticalAlignment = VerticalAlignment.Center });

            txtServiceSearch = new TextBox { Width = 200, Margin = new Thickness(5) };
            txtServiceSearch.TextChanged += (s, e) => SearchServices();
            servicePanel.Children.Add(txtServiceSearch);

            var btnAddService = new Button { Content = "Добавить", Margin = new Thickness(5) };
            btnAddService.Click += (s, e) => AddSelectedServices();
            servicePanel.Children.Add(btnAddService);

            grid.Children.Add(servicePanel);
            servicePanel.SetValue(Grid.RowProperty, 3);

            // Результаты поиска услуг
            lstServiceResults = new ListBox { MaxHeight = 100, Margin = new Thickness(5), Visibility = Visibility.Collapsed };
            lstServiceResults.SelectionChanged += (s, e) => AddServiceFromList();
            grid.Children.Add(lstServiceResults);
            lstServiceResults.SetValue(Grid.RowProperty, 4);

            // Выбранные услуги
            lstServices = new ListBox { Margin = new Thickness(5) };
            grid.Children.Add(lstServices);
            lstServices.SetValue(Grid.RowProperty, 5);

            // Кнопка создания заказа
            var btnCreateOrder = new Button
            {
                Content = "Создать заказ",
                Margin = new Thickness(5),
                HorizontalAlignment = HorizontalAlignment.Right,
                Padding = new Thickness(10, 5, 10, 5)
            };
            btnCreateOrder.Click += (s, e) => CreateOrder();
            grid.Children.Add(btnCreateOrder);
            btnCreateOrder.SetValue(Grid.RowProperty, 6);

            this.Content = grid;
        }

        private string GetNextTubeCode()
        {
            try
            {
                var lastOrder = Database.GetOrders(DateTime.MinValue, DateTime.MaxValue)
                                      .Where(o => !string.IsNullOrEmpty(o.TubeCode))
                                      .OrderByDescending(o => o.CreatedDate)
                                      .FirstOrDefault();

                if (lastOrder == null)
                    return "TUBE-0001";

                // Извлекаем числовую часть из последнего кода
                var match = Regex.Match(lastOrder.TubeCode, @"\d+");
                if (match.Success)
                {
                    int lastNumber = int.Parse(match.Value);
                    return $"TUBE-{(lastNumber + 1).ToString("D4")}"; // Форматируем с ведущими нулями
                }

                return "TUBE-" + Guid.NewGuid().ToString().Substring(0, 4).ToUpper();
            }
            catch
            {
                // Резервный вариант генерации кода
                return "TUBE-" + DateTime.Now.ToString("HHmmss");
            }
        }

        private void GenerateBarcode()
        {
            if (string.IsNullOrEmpty(txtTubeCode.Text))
            {
                MessageBox.Show("Введите код пробирки");
                return;
            }

            var barcode = Database.GenerateBarcode();
            new BarcodeWindow(barcode).ShowDialog();
        }

        private void SearchPatients()
        {
            lstPatientResults.Items.Clear();
            var results = Database.SearchPatients(txtPatientSearch.Text);

            foreach (var patient in results)
            {
                lstPatientResults.Items.Add($"{patient.LastName} {patient.FirstName} ({patient.BirthDate:dd.MM.yyyy})");
            }

            lstPatientResults.Visibility = results.Any() ? Visibility.Visible : Visibility.Collapsed;
        }

        private void SelectPatient()
        {
            if (lstPatientResults.SelectedItem == null) return;

            var selected = lstPatientResults.SelectedItem.ToString();
            selectedPatient = Database.SearchPatients(txtPatientSearch.Text)
                .FirstOrDefault(p => $"{p.LastName} {p.FirstName} ({p.BirthDate:dd.MM.yyyy})" == selected);

            if (selectedPatient != null)
            {
                txtPatientSearch.Text = $"{selectedPatient.LastName} {selectedPatient.FirstName}";
                lstPatientResults.Visibility = Visibility.Collapsed;
            }
        }

        private void AddNewPatient()
        {
            var window = new AddPatientWindow();
            if (window.ShowDialog() == true)
            {
                Database.AddPatient(window.NewPatient);
                selectedPatient = window.NewPatient;
                txtPatientSearch.Text = selectedPatient.FullName;
            }
        }

        private void SearchServices()
        {
            lstServiceResults.Items.Clear();
            var results = Database.SearchServices(txtServiceSearch.Text);

            foreach (var service in results)
            {
                lstServiceResults.Items.Add($"{service.Name} - {service.Price} руб.");
            }

            lstServiceResults.Visibility = results.Any() ? Visibility.Visible : Visibility.Collapsed;
        }

        private void AddServiceFromList()
        {
            if (lstServiceResults.SelectedItem == null) return;

            var selected = lstServiceResults.SelectedItem.ToString();
            var service = Database.SearchServices(txtServiceSearch.Text)
                .FirstOrDefault(s => $"{s.Name} - {s.Price} руб." == selected);

            if (service != null && !selectedServices.Contains(service))
            {
                selectedServices.Add(service);
                UpdateServicesList();
            }
        }

        private void AddSelectedServices()
        {
            var window = new ServiceSelectionWindow(Database.SearchServices(""));
            if (window.ShowDialog() == true)
            {
                selectedServices.AddRange(window.SelectedServices);
                UpdateServicesList();
            }
        }

        private void UpdateServicesList()
        {
            lstServices.Items.Clear();
            foreach (var service in selectedServices)
            {
                lstServices.Items.Add($"{service.Name} - {service.Price} руб.");
            }
        }

        private void CreateOrder()
        {
            if (string.IsNullOrEmpty(txtTubeCode.Text))
            {
                MessageBox.Show("Введите код пробирки");
                return;
            }

            if (selectedPatient == null)
            {
                MessageBox.Show("Выберите пациента");
                return;
            }

            if (!selectedServices.Any())
            {
                MessageBox.Show("Добавьте хотя бы одну услугу");
                return;
            }

            var order = Database.CreateOrder(
                txtTubeCode.Text,
                selectedPatient,
                selectedServices,
                "current_user" // В реальном приложении использовать текущего пользователя
            );

            MessageBox.Show($"Заказ создан!\nНомер: {order.OrderId}\nСумма: {order.TotalPrice} руб.");

            // Сброс формы
            txtTubeCode.Text = GetNextTubeCode();
            selectedPatient = null;
            selectedServices.Clear();
            UpdateServicesList();
            txtPatientSearch.Text = "";
            txtServiceSearch.Text = "";
        }
    }

    public class ReportsView : UserControl
    {
        private DataGrid ordersGrid;
        private DatePicker dateFromPicker;
        private DatePicker dateToPicker;
        private ComboBox userComboBox;

        public ReportsView(User currentUser)
        {
            var grid = new Grid();
            grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
            grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });

            // Панель фильтров
            var filterPanel = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(5) };

            dateFromPicker = new DatePicker { Width = 120, Margin = new Thickness(5), SelectedDate = DateTime.Today.AddDays(-7) };
            filterPanel.Children.Add(new Label { Content = "С:", VerticalAlignment = VerticalAlignment.Center });
            filterPanel.Children.Add(dateFromPicker);

            dateToPicker = new DatePicker { Width = 120, Margin = new Thickness(5), SelectedDate = DateTime.Today };
            filterPanel.Children.Add(new Label { Content = "По:", VerticalAlignment = VerticalAlignment.Center });
            filterPanel.Children.Add(dateToPicker);

            userComboBox = new ComboBox
            {
                Width = 200,
                Margin = new Thickness(5),
                DisplayMemberPath = "FullName"
            };
            filterPanel.Children.Add(new Label { Content = "Лаборант:", VerticalAlignment = VerticalAlignment.Center });
            filterPanel.Children.Add(userComboBox);

            var btnGenerate = new Button
            {
                Content = "Сформировать",
                Margin = new Thickness(5),
                Width = 100
            };
            btnGenerate.Click += (s, e) => GenerateReport();
            filterPanel.Children.Add(btnGenerate);

            grid.Children.Add(filterPanel);

            // Таблица заказов
            ordersGrid = new DataGrid
            {
                Margin = new Thickness(5),
                AutoGenerateColumns = false,
                IsReadOnly = true
            };

            ordersGrid.Columns.Add(new DataGridTextColumn
            {
                Header = "№",
                Binding = new Binding("OrderId"),
                Width = 100
            });

            ordersGrid.Columns.Add(new DataGridTextColumn
            {
                Header = "Дата",
                Binding = new Binding("CreatedDate") { StringFormat = "dd.MM.yyyy HH:mm" },
                Width = 120
            });

            ordersGrid.Columns.Add(new DataGridTextColumn
            {
                Header = "Пациент",
                Binding = new Binding("Patient.FullName"),
                Width = 200
            });

            ordersGrid.Columns.Add(new DataGridTextColumn
            {
                Header = "Услуг",
                Binding = new Binding("Services.Count"),
                Width = 60
            });

            ordersGrid.Columns.Add(new DataGridTextColumn
            {
                Header = "Сумма",
                Binding = new Binding("TotalPrice") { StringFormat = "{0:N2} руб." },
                Width = 100
            });

            grid.Children.Add(ordersGrid);
            ordersGrid.SetValue(Grid.RowProperty, 1);

            // Кнопка экспорта
            var btnExport = new Button
            {
                Content = "Экспорт в Excel",
                Margin = new Thickness(5),
                HorizontalAlignment = HorizontalAlignment.Right,
                Width = 120
            };
            btnExport.Click += (s, e) => ExportToExcel();
            grid.Children.Add(btnExport);
            btnExport.SetValue(Grid.RowProperty, 2);

            this.Content = grid;
            LoadUsers();
        }

        private void LoadUsers()
        {
            userComboBox.ItemsSource = Database.GetAllUsers()
                .Where(u => u.Role == UserRole.LabAssistant || u.Role == UserRole.ResearchAssistant)
                .ToList();
        }

        private void GenerateReport()
        {
            var fromDate = dateFromPicker.SelectedDate ?? DateTime.Today.AddDays(-7);
            var toDate = dateToPicker.SelectedDate ?? DateTime.Today;
            var user = userComboBox.SelectedItem as User;

            ordersGrid.ItemsSource = Database.GetOrders(
                fromDate,
                toDate,
                user?.Username
            );
        }

        private void ExportToExcel()
        {
            MessageBox.Show("Отчет экспортирован в Excel", "Экспорт", MessageBoxButton.OK, MessageBoxImage.Information);
        }
    }

    public class AnalyzerView : UserControl
    {
        public AnalyzerView()
        {
            var stackPanel = new StackPanel();

            var label = new Label
            {
                Content = "Работа с анализатором",
                FontSize = 16,
                HorizontalAlignment = HorizontalAlignment.Center
            };
            stackPanel.Children.Add(label);

            var btnStart = new Button
            {
                Content = "Запустить анализ",
                Margin = new Thickness(20),
                Padding = new Thickness(10),
                HorizontalAlignment = HorizontalAlignment.Center
            };
            btnStart.Click += (s, e) => MessageBox.Show("Анализ запущен");
            stackPanel.Children.Add(btnStart);

            this.Content = stackPanel;
        }
    }

    public class InsuranceInvoicesView : UserControl
    {
        public InsuranceInvoicesView()
        {
            var stackPanel = new StackPanel();

            var label = new Label
            {
                Content = "Счета страховым компаниям",
                FontSize = 16,
                HorizontalAlignment = HorizontalAlignment.Center
            };
            stackPanel.Children.Add(label);

            var dataGrid = new DataGrid
            {
                Margin = new Thickness(10),
                AutoGenerateColumns = false,
                IsReadOnly = true
            };

            dataGrid.Columns.Add(new DataGridTextColumn
            {
                Header = "Номер",
                Binding = new Binding("Number"),
                Width = 100
            });

            dataGrid.Columns.Add(new DataGridTextColumn
            {
                Header = "Дата",
                Binding = new Binding("Date") { StringFormat = "dd.MM.yyyy" },
                Width = 100
            });

            dataGrid.Columns.Add(new DataGridTextColumn
            {
                Header = "Компания",
                Binding = new Binding("Company"),
                Width = 200
            });

            dataGrid.Columns.Add(new DataGridTextColumn
            {
                Header = "Сумма",
                Binding = new Binding("Amount") { StringFormat = "{0:N2} руб." },
                Width = 100
            });

            stackPanel.Children.Add(dataGrid);

            this.Content = stackPanel;
        }
    }

    public class UsersView : UserControl
    {
        private DataGrid usersGrid;

        public UsersView()
        {
            var grid = new Grid();
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
            grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });

            usersGrid = new DataGrid
            {
                Margin = new Thickness(5),
                AutoGenerateColumns = false,
                IsReadOnly = true
            };

            usersGrid.Columns.Add(new DataGridTextColumn
            {
                Header = "Логин",
                Binding = new Binding("Username"),
                Width = 120
            });

            usersGrid.Columns.Add(new DataGridTextColumn
            {
                Header = "ФИО",
                Binding = new Binding("FullName"),
                Width = 200
            });

            var roleColumn = new DataGridTextColumn
            {
                Header = "Роль",
                Binding = new Binding("Role"),
                Width = 150
            };
           
            usersGrid.Columns.Add(roleColumn);

            usersGrid.Columns.Add(new DataGridTextColumn
            {
                Header = "Дата регистрации",
                Binding = new Binding("RegistrationDate") { StringFormat = "dd.MM.yyyy" },
                Width = 120
            });

            grid.Children.Add(usersGrid);

            // Панель кнопок
            var buttonPanel = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                HorizontalAlignment = HorizontalAlignment.Right,
                Margin = new Thickness(5)
            };

            var btnAdd = new Button
            {
                Content = "Добавить",
                Margin = new Thickness(5),
                Width = 100
            };
            btnAdd.Click += (s, e) => AddUser();
            buttonPanel.Children.Add(btnAdd);

            var btnEdit = new Button
            {
                Content = "Редактировать",
                Margin = new Thickness(5),
                Width = 100
            };
            btnEdit.Click += (s, e) => EditUser();
            buttonPanel.Children.Add(btnEdit);

            var btnDelete = new Button
            {
                Content = "Удалить",
                Margin = new Thickness(5),
                Width = 100
            };
            btnDelete.Click += (s, e) => DeleteUser();
            buttonPanel.Children.Add(btnDelete);

            grid.Children.Add(buttonPanel);
            buttonPanel.SetValue(Grid.RowProperty, 1);

            this.Content = grid;
            LoadUsers();
        }

        private void LoadUsers()
        {
            usersGrid.ItemsSource = Database.GetAllUsers();
        }

        private void AddUser()
        {
            var window = new RegisterWindow();
            if (window.ShowDialog() == true)
            {
                LoadUsers();
            }
        }

        private void EditUser()
        {
            if (usersGrid.SelectedItem is User selectedUser)
            {
                var window = new RegisterWindow(selectedUser);
                if (window.ShowDialog() == true)
                {
                    LoadUsers();
                }
            }
            else
            {
                MessageBox.Show("Выберите пользователя", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void DeleteUser()
        {
            if (usersGrid.SelectedItem is User selectedUser)
            {
                if (MessageBox.Show($"Удалить пользователя {selectedUser.Username}?",
                    "Подтверждение", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
                {
                    Database.DeleteUser(selectedUser.Username);
                    LoadUsers();
                }
            }
            else
            {
                MessageBox.Show("Выберите пользователя", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }
    }

    public class SuppliesView : UserControl
    {
        public SuppliesView()
        {
            var stackPanel = new StackPanel();

            var label = new Label
            {
                Content = "Расходные материалы",
                FontSize = 16,
                HorizontalAlignment = HorizontalAlignment.Center
            };
            stackPanel.Children.Add(label);

            var dataGrid = new DataGrid
            {
                Margin = new Thickness(10),
                AutoGenerateColumns = false
            };

            dataGrid.Columns.Add(new DataGridTextColumn
            {
                Header = "Наименование",
                Binding = new Binding("Name"),
                Width = 200
            });

            dataGrid.Columns.Add(new DataGridTextColumn
            {
                Header = "Количество",
                Binding = new Binding("Quantity"),
                Width = 100
            });

            dataGrid.Columns.Add(new DataGridTextColumn
            {
                Header = "Ед.изм.",
                Binding = new Binding("Unit"),
                Width = 80
            });

            dataGrid.Columns.Add(new DataGridTextColumn
            {
                Header = "Мин.запас",
                Binding = new Binding("MinStock"),
                Width = 100
            });

            stackPanel.Children.Add(dataGrid);

            this.Content = stackPanel;
        }
    }
}