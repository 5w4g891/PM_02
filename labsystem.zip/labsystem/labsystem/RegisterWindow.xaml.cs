﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace labsystem
{
    /// <summary>
    /// Логика взаимодействия для RegisterWindow.xaml
    /// </summary>
    public partial class RegisterWindow : Window
    {
        private bool isEditMode;
        private User originalUser;

        public RegisterWindow()
        {
            InitializeComponent();
            Title = "Добавление пользователя";
        }

        public RegisterWindow(User user) : this()
        {
            isEditMode = true;
            originalUser = user;
            Title = "Редактирование пользователя";

            txtUsername.Text = user.Username;
            txtFirstName.Text = user.FirstName;
            txtLastName.Text = user.LastName;

            // Заполняем остальные поля...
            cmbRole.SelectedIndex = (int)user.Role;
        }

        // Обработчик кнопки регистрации
        private void Register_Click(object sender, RoutedEventArgs e)
        {
            txtError.Visibility = Visibility.Collapsed;

            // Валидация данных
            if (string.IsNullOrWhiteSpace(txtUsername.Text))
            {
                ShowError("Введите логин");
                return;
            }

            if (txtPassword.Password.Length < 4)
            {
                ShowError("Пароль должен содержать минимум 4 символа");
                return;
            }

            if (txtPassword.Password != txtConfirmPassword.Password)
            {
                ShowError("Пароли не совпадают");
                return;
            }

            if (string.IsNullOrWhiteSpace(txtFirstName.Text) || string.IsNullOrWhiteSpace(txtLastName.Text))
            {
                ShowError("Введите имя и фамилию");
                return;
            }

            if (cmbRole.SelectedItem == null)
            {
                ShowError("Выберите роль");
                return;
            }
            if (isEditMode)
            {
                // Обновляем существующего пользователя
                originalUser.FirstName = txtFirstName.Text;
                originalUser.LastName = txtLastName.Text;
                originalUser.Role = (UserRole)cmbRole.SelectedIndex;

                // В реальном приложении здесь будет сохранение в БД
                MessageBox.Show("Пользователь успешно обновлен");
            }
            else
            {
                // Создаем нового пользователя
                var newUser = new User
                {
                    Username = txtUsername.Text,
                    Password = txtPassword.Password,
                    FirstName = txtFirstName.Text,
                    LastName = txtLastName.Text,
                    Photo = "/Resources/default_user.jpg",
                    Role = (UserRole)cmbRole.SelectedIndex,
                    RegistrationDate = DateTime.Now
                };

                Database.AddUser(newUser);
                MessageBox.Show("Пользователь успешно добавлен");
            }

            DialogResult = true;
            Close();



            // Проверка уникальности логина
            if (Database.GetAllUsers().Any(u => u.Username == txtUsername.Text))
            {
                ShowError("Пользователь с таким логином уже существует");
                return;
            }

        }

        // Показать сообщение об ошибке
        private void ShowError(string message)
        {
            txtError.Text = message;
            txtError.Visibility = Visibility.Visible;
        }

        // Обработчик кнопки отмены
        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }
}