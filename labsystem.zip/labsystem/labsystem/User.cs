﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace labsystem
{
    public enum UserRole
    {
        LabAssistant,
        ResearchAssistant,
        Accountant,
        Administrator
    }

    public class User
    {
        public string Username { get; set; }
        public string Password { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Photo { get; set; }
        public UserRole Role { get; set; }
        public DateTime RegistrationDate { get; set; } = DateTime.Now;
        public string FullName => $"{LastName} {FirstName}";
    }

    public class Patient
    {
        public string Id { get; set; } = Guid.NewGuid().ToString();
        public string LastName { get; set; }
        public string FirstName { get; set; }
        public string MiddleName { get; set; }
        public DateTime BirthDate { get; set; }
        public string PassportSeries { get; set; }
        public string PassportNumber { get; set; }
        public string Phone { get; set; }
        public string Email { get; set; }
        public string InsurancePolicyNumber { get; set; }
        public string InsurancePolicyType { get; set; }
        public string InsuranceCompany { get; set; }
        public string FullName => $"{LastName} {FirstName} {MiddleName}";
    }

    public class Service
    {
        public string Id { get; set; } = Guid.NewGuid().ToString();
        public string Name { get; set; }
        public string Code { get; set; }
        public decimal Price { get; set; }
        public string Description { get; set; }
    }

    public class Order
    {
        public string OrderId { get; set; } = Guid.NewGuid().ToString();
        public DateTime CreatedDate { get; set; } = DateTime.Now;
        public string TubeCode { get; set; }
        public string Barcode { get; set; }
        public Patient Patient { get; set; }
        public List<Service> Services { get; set; } = new List<Service>();
        public decimal TotalPrice => Services.Sum(s => s.Price);
        public string UserId { get; set; }
        public bool IsArchived { get; set; }
        public bool IsPaid { get; set; } // Новое поле для бухгалтера

        public User User => Database.GetAllUsers().FirstOrDefault(u => u.Username == UserId);
    }

    public class RoleToStringConverter : System.Windows.Data.IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            if (value is UserRole role)
            {
                switch (role)
                {
                    case UserRole.LabAssistant: return "Лаборант";
                    case UserRole.ResearchAssistant: return "Лаборант-исследователь";
                    case UserRole.Accountant: return "Бухгалтер";
                    case UserRole.Administrator: return "Администратор";
                }
            }
            return string.Empty;
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
