﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace labsystem
{
    /// <summary>
    /// Логика взаимодействия для ServiceSelectionWindow.xaml
    /// </summary>
    public partial class ServiceSelectionWindow : Window
    {
        public List<Service> SelectedServices { get; } = new List<Service>();

        public ServiceSelectionWindow(List<Service> services)
        {
            InitializeComponent();
            servicesGrid.ItemsSource = services;
        }

        private void Select_Click(object sender, RoutedEventArgs e)
        {
            SelectedServices.Clear();
            SelectedServices.AddRange(servicesGrid.SelectedItems.Cast<Service>());
            DialogResult = true;
            Close();
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }
}
