﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CyberSports
{
    /// <summary>
    /// Логика взаимодействия для MatchesPage.xaml
    /// </summary>
    public partial class MatchesPage : Page
    {
        public MatchesPage()
        {
            InitializeComponent();
            LoadTournaments();
        }

        private void LoadTournaments()
        {
            try
            {
                string query = "SELECT TournamentID, TournamentName FROM Tournaments ORDER BY StartDate DESC";

                using (SqlCommand cmd = new SqlCommand(query, App.Connection))
                {
                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                    cmbTournaments.ItemsSource = dt.DefaultView;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке турниров: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void TournamentChanged(object sender, SelectionChangedEventArgs e)
        {
            if (cmbTournaments.SelectedValue == null) return;

            int tournamentId = (int)cmbTournaments.SelectedValue;
            LoadMatches(tournamentId);
        }

        private void LoadMatches(int tournamentId)
        {
            try
            {
                string query = @"
                    SELECT 
                        m.MatchID,
                        t.TournamentName,
                        m.RoundNumber,
                        m.MatchNumber,
                        m.StartTime,
                        m.Status,
                        t1.TeamName AS Team1Name,
                        t2.TeamName AS Team2Name,
                        CONCAT(ISNULL(mp1.Score, 0), ':', ISNULL(mp2.Score, 0)) AS Score
                    FROM Matches m
                    JOIN Tournaments t ON m.TournamentID = t.TournamentID
                    LEFT JOIN (
                        SELECT MatchID, TeamID, Score 
                        FROM MatchParticipants 
                        WHERE ParticipantOrder = 1
                    ) mp1 ON m.MatchID = mp1.MatchID
                    LEFT JOIN Teams t1 ON mp1.TeamID = t1.TeamID
                    LEFT JOIN (
                        SELECT MatchID, TeamID, Score 
                        FROM MatchParticipants 
                        WHERE ParticipantOrder = 2
                    ) mp2 ON m.MatchID = mp2.MatchID
                    LEFT JOIN Teams t2 ON mp2.TeamID = t2.TeamID
                    WHERE m.TournamentID = @TournamentID
                    ORDER BY m.RoundNumber, m.MatchNumber";

                using (SqlCommand cmd = new SqlCommand(query, App.Connection))
                {
                    cmd.Parameters.AddWithValue("@TournamentID", tournamentId);

                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                    MatchesGrid.ItemsSource = dt.DefaultView;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке матчей: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void AddMatch_Click(object sender, RoutedEventArgs e)
        {
            if (cmbTournaments.SelectedValue == null)
            {
                MessageBox.Show("Выберите турнир", "Информация", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            int tournamentId = (int)cmbTournaments.SelectedValue;
            MatchEditWindow editWindow = new MatchEditWindow(tournamentId);
            if (editWindow.ShowDialog() == true)
            {
                LoadMatches(tournamentId);
            }
        }

        private void EditMatch_Click(object sender, RoutedEventArgs e)
        {
            if (MatchesGrid.SelectedItem == null)
            {
                MessageBox.Show("Выберите матч для редактирования", "Информация", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            DataRowView row = (DataRowView)MatchesGrid.SelectedItem;
            int matchId = (int)row["MatchID"];

            MatchEditWindow editWindow = new MatchEditWindow(matchId);
            if (editWindow.ShowDialog() == true)
            {
                if (cmbTournaments.SelectedValue != null)
                {
                    int tournamentId = (int)cmbTournaments.SelectedValue;
                    LoadMatches(tournamentId);
                }
            }
        }

        private void DeleteMatch_Click(object sender, RoutedEventArgs e)
        {
            if (MatchesGrid.SelectedItem == null)
            {
                MessageBox.Show("Выберите матч для удаления", "Информация", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            DataRowView row = (DataRowView)MatchesGrid.SelectedItem;
            int matchId = (int)row["MatchID"];
            string matchInfo = $"Матч #{row["MatchNumber"]} (Раунд {row["RoundNumber"]})";

            if (MessageBox.Show($"Вы уверены, что хотите удалить матч '{matchInfo}'?",
                "Подтверждение удаления", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    string query = "DELETE FROM Matches WHERE MatchID = @MatchID";
                    using (SqlCommand cmd = new SqlCommand(query, App.Connection))
                    {
                        cmd.Parameters.AddWithValue("@MatchID", matchId);
                        cmd.ExecuteNonQuery();
                    }

                    MessageBox.Show("Матч успешно удален", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                    if (cmbTournaments.SelectedValue != null)
                    {
                        int tournamentId = (int)cmbTournaments.SelectedValue;
                        LoadMatches(tournamentId);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при удалении матча: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void CompleteMatch_Click(object sender, RoutedEventArgs e)
        {
            if (MatchesGrid.SelectedItem == null)
            {
                MessageBox.Show("Выберите матч для завершения", "Информация",
                               MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            DataRowView row = (DataRowView)MatchesGrid.SelectedItem;
            int matchId = (int)row["MatchID"];

            MatchResultWindow resultWindow = new MatchResultWindow(matchId);
            if (resultWindow.ShowDialog() == true)
            {
                if (cmbTournaments.SelectedValue != null)
                {
                    int tournamentId = (int)cmbTournaments.SelectedValue;
                    LoadMatches(tournamentId);
                }
            }
        }
    }
}
