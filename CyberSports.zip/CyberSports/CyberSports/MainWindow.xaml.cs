﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CyberSports
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            MainFrame.Navigate(new TournamentsPage());
        }
        private void NavButton_Click(object sender, RoutedEventArgs e)
        {
            var button = (Button)sender;

            switch (button.Name)
            {
                case "btnTournaments":
                    MainFrame.Navigate(new TournamentsPage());
                    break;
                case "btnTeams":
                    MainFrame.Navigate(content: new TeamsPage());
                    break;
                case "btnPlayers":
                    MainFrame.Navigate(new PlayersPage());
                    break;
                case "btnMatches":
                    MainFrame.Navigate(new MatchesPage());
                    break;
                case "btnGames":
                    MainFrame.Navigate(new GamesPage());
                    break;
                case "btnStats":
                    MainFrame.Navigate(new StatisticsPage());
                    break;
                case "btnUsers":
                    MainFrame.Navigate(new UsersPage());
                    break;
            }
        }
    }
}
