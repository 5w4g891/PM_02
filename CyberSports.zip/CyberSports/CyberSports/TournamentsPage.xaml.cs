﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CyberSports
{
    /// <summary>
    /// Логика взаимодействия для TournamentsPage.xaml
    /// </summary>
    public partial class TournamentsPage : Page
    {
        public TournamentsPage()
        {
            InitializeComponent();
            LoadTournaments();
        }

        private void LoadTournaments(string filter = "All")
        {
            try
            {
                string query = @"
                    SELECT t.TournamentID, t.TournamentName, g.GameName, t.StartDate, 
                           t.EndDate, t.PrizePool, t.IsCompleted
                    FROM Tournaments t
                    JOIN Games g ON t.GameID = g.GameID
                    WHERE (@Filter = 'All' OR 
                          (@Filter = 'Active' AND t.StartDate <= GETDATE() AND t.EndDate >= GETDATE()) OR
                          (@Filter = 'Completed' AND t.IsCompleted = 1) OR
                          (@Filter = 'Upcoming' AND t.StartDate > GETDATE()))
                    ORDER BY t.StartDate DESC";

                using (SqlCommand cmd = new SqlCommand(query, App.Connection))
                {
                    cmd.Parameters.AddWithValue("@Filter", filter);

                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                    TournamentsGrid.ItemsSource = dt.DefaultView;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке турниров: {ex.Message}",
                              "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void SearchTournaments(object sender, System.Windows.Input.KeyEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtSearch.Text))
            {
                LoadTournaments();
                return;
            }

            try
            {
                string query = @"
                    SELECT t.TournamentID, t.TournamentName, g.GameName, t.StartDate, 
                           t.EndDate, t.PrizePool, t.IsCompleted
                    FROM Tournaments t
                    JOIN Games g ON t.GameID = g.GameID
                    WHERE t.TournamentName LIKE @Search OR g.GameName LIKE @Search
                    ORDER BY t.StartDate DESC";

                using (SqlCommand cmd = new SqlCommand(query, App.Connection))
                {
                    cmd.Parameters.AddWithValue("@Search", $"%{txtSearch.Text}%");

                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                    TournamentsGrid.ItemsSource = dt.DefaultView;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при поиске турниров: {ex.Message}",
                              "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void FilterChanged(object sender, SelectionChangedEventArgs e)
        {
            string filter = "All";
            switch (cmbFilter.SelectedIndex)
            {
                case 1: filter = "Active"; break;
                case 2: filter = "Completed"; break;
                case 3: filter = "Upcoming"; break;
            }

            LoadTournaments(filter);
        }

        private void TournamentsGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            bool isSelected = TournamentsGrid.SelectedItem != null;
            btnEdit.IsEnabled = isSelected;
            btnDelete.IsEnabled = isSelected;
        }

        private void AddTournament_Click(object sender, RoutedEventArgs e)
        {
            TournamentEditWindow editWindow = new TournamentEditWindow();
            if (editWindow.ShowDialog() == true)
            {
                LoadTournaments();
            }
        }

        private void EditTournament_Click(object sender, RoutedEventArgs e)
        {
            if (TournamentsGrid.SelectedItem == null)
            {
                MessageBox.Show("Выберите турнир для редактирования",
                              "Информация", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            DataRowView row = (DataRowView)TournamentsGrid.SelectedItem;
            int tournamentId = (int)row["TournamentID"];

            TournamentEditWindow editWindow = new TournamentEditWindow(tournamentId);
            if (editWindow.ShowDialog() == true)
            {
                LoadTournaments();
            }
        }

        private void DeleteTournament_Click(object sender, RoutedEventArgs e)
        {
            if (TournamentsGrid.SelectedItem == null)
            {
                MessageBox.Show("Выберите турнир для удаления",
                              "Информация", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            DataRowView row = (DataRowView)TournamentsGrid.SelectedItem;
            int tournamentId = (int)row["TournamentID"];
            string tournamentName = row["TournamentName"].ToString();

            if (MessageBox.Show($"Вы уверены, что хотите удалить турнир '{tournamentName}'?",
                "Подтверждение удаления", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    string query = "DELETE FROM Tournaments WHERE TournamentID = @TournamentID";
                    using (SqlCommand cmd = new SqlCommand(query, App.Connection))
                    {
                        cmd.Parameters.AddWithValue("@TournamentID", tournamentId);
                        cmd.ExecuteNonQuery();
                    }

                    MessageBox.Show("Турнир успешно удален",
                                  "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                    LoadTournaments();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при удалении турнира: {ex.Message}",
                                  "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }
    }
}