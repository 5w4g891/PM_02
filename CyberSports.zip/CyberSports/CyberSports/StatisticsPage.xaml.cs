﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using LiveCharts;
using LiveCharts.Wpf;
using LiveCharts.Defaults;
using LiveCharts.Helpers;
namespace CyberSports
{
    /// <summary>
    /// Логика взаимодействия для StatisticsPage.xaml
    /// </summary>
    public partial class StatisticsPage : Window
    {
        public StatisticsPage()
        {
            InitializeComponent();
            LoadTournaments();
        }
        private void LoadTournaments()
        {
            try
            {
                string query = "SELECT TournamentID, TournamentName FROM Tournaments ORDER BY StartDate DESC";

                using (SqlCommand cmd = new SqlCommand(query, App.Connection))
                {
                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                    cmbTournaments.ItemsSource = dt.DefaultView;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке турниров: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void cmbTournaments_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (cmbTournaments.SelectedValue == null) return;

            int tournamentId = (int)cmbTournaments.SelectedValue;
            LoadTeams(tournamentId);
        }

        private void LoadTeams(int tournamentId)
        {
            try
            {
                string query = @"
                    SELECT t.TeamID, t.TeamName 
                    FROM Teams t
                    JOIN TournamentRegistrations tr ON t.TeamID = tr.TeamID
                    WHERE tr.TournamentID = @TournamentID AND tr.IsApproved = 1
                    ORDER BY t.TeamName";

                using (SqlCommand cmd = new SqlCommand(query, App.Connection))
                {
                    cmd.Parameters.AddWithValue("@TournamentID", tournamentId);

                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                    cmbTeams.ItemsSource = dt.DefaultView;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке команд: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void ShowStats_Click(object sender, RoutedEventArgs e)
        {
            if (cmbTournaments.SelectedValue == null)
            {
                MessageBox.Show("Выберите турнир", "Информация", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            int tournamentId = (int)cmbTournaments.SelectedValue;
            int? teamId = cmbTeams.SelectedValue as int?;

            LoadPlayerStats(tournamentId, teamId);
        }

        private void LoadPlayerStats(int tournamentId, int? teamId)
        {
            try
            {
                string query = @"
                    SELECT 
                        p.Nickname AS PlayerName,
                        t.TeamName,
                        COUNT(ps.StatID) AS MatchesPlayed,
                        SUM(ps.Kills) AS Kills,
                        SUM(ps.Deaths) AS Deaths,
                        SUM(ps.Assists) AS Assists,
                        CASE WHEN SUM(ps.Deaths) = 0 THEN SUM(ps.Kills) + SUM(ps.Assists)
                             ELSE (SUM(ps.Kills) + SUM(ps.Assists)) * 1.0 / SUM(ps.Deaths) END AS KDA,
                        SUM(ps.DamageDealt) AS DamageDealt,
                        SUM(ps.HealingDone) AS HealingDone
                    FROM PlayerStats ps
                    JOIN Players p ON ps.PlayerID = p.PlayerID
                    JOIN Teams t ON p.TeamID = t.TeamID
                    JOIN Matches m ON ps.MatchID = m.MatchID
                    WHERE m.TournamentID = @TournamentID
                          AND (@TeamID IS NULL OR p.TeamID = @TeamID)
                    GROUP BY p.PlayerID, p.Nickname, t.TeamID, t.TeamName
                    ORDER BY KDA DESC";

                using (SqlCommand cmd = new SqlCommand(query, App.Connection))
                {
                    cmd.Parameters.AddWithValue("@TournamentID", tournamentId);
                    cmd.Parameters.AddWithValue("@TeamID", teamId ?? (object)DBNull.Value);

                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                    StatsGrid.ItemsSource = dt.DefaultView;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке статистики: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void ShowKDAGraph_Click(object sender, RoutedEventArgs e)
        {
            if (StatsGrid.ItemsSource == null || ((DataView)StatsGrid.ItemsSource).Count == 0)
            {
                MessageBox.Show("Нет данных для отображения", "Информация", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            var chartWindow = new Window
            {
                Title = "График KDA игроков",
                Width = 800,
                Height = 500,
                WindowStartupLocation = WindowStartupLocation.CenterOwner
            };

            var chart = new CartesianChart
            {
                Series = new SeriesCollection(),
                LegendLocation = LegendLocation.Right,
                Background = Brushes.White
            };

            chart.AxisX.Add(new Axis
            {
                Title = "Игроки",
                Labels = ((DataView)StatsGrid.ItemsSource).ToTable().AsEnumerable()
                    .Select(row => row["PlayerName"].ToString()).ToArray()
            });

            chart.AxisY.Add(new Axis
            {
                Title = "KDA"
            });

            chart.Series.Add(new ColumnSeries
            {
                Title = "KDA",
                Values = new ChartValues<double>(
                    ((DataView)StatsGrid.ItemsSource).ToTable().AsEnumerable()
                    .Select(row => Convert.ToDouble(row["KDA"])))
            });

            chartWindow.Content = chart;
            chartWindow.ShowDialog();
        }
    }
}
