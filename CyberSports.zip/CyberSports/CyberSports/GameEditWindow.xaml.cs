﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CyberSports
{
    /// <summary>
    /// Логика взаимодействия для GameEditWindow.xaml
    /// </summary>
    public partial class GameEditWindow : Window
    {
        private int? _gameId;

        public GameEditWindow(int? gameId = null)
        {
            InitializeComponent();
            _gameId = gameId;

            if (_gameId.HasValue)
            {
                LoadGameData();
            }
            else
            {
                dpReleaseDate.SelectedDate = DateTime.Today;
                chkIsActive.IsChecked = true;
            }
        }

        private void LoadGameData()
        {
            try
            {
                string query = "SELECT GameName, Developer, ReleaseDate, MaxPlayersPerTeam, IsActive FROM Games WHERE GameID = @GameID";

                using (SqlCommand cmd = new SqlCommand(query, App.Connection))
                {
                    cmd.Parameters.AddWithValue("@GameID", _gameId.Value);

                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            txtGameName.Text = reader["GameName"].ToString();
                            txtDeveloper.Text = reader["Developer"].ToString();
                            dpReleaseDate.SelectedDate = (DateTime)reader["ReleaseDate"];

                            int maxPlayers = (int)reader["MaxPlayersPerTeam"];
                            foreach (ComboBoxItem item in cmbPlayersPerTeam.Items)
                            {
                                if (int.Parse(item.Content.ToString()) == maxPlayers)
                                {
                                    cmbPlayersPerTeam.SelectedItem = item;
                                    break;
                                }
                            }

                            chkIsActive.IsChecked = (bool)reader["IsActive"];
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке данных игры: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtGameName.Text))
            {
                MessageBox.Show("Введите название игры", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (!dpReleaseDate.SelectedDate.HasValue)
            {
                MessageBox.Show("Выберите дату выхода", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                int maxPlayers = int.Parse(((ComboBoxItem)cmbPlayersPerTeam.SelectedItem).Content.ToString());

                if (_gameId.HasValue)
                {
                    string updateQuery = @"
                        UPDATE Games 
                        SET GameName = @GameName,
                            Developer = @Developer,
                            ReleaseDate = @ReleaseDate,
                            MaxPlayersPerTeam = @MaxPlayers,
                            IsActive = @IsActive
                        WHERE GameID = @GameID";

                    using (SqlCommand cmd = new SqlCommand(updateQuery, App.Connection))
                    {
                        cmd.Parameters.AddWithValue("@GameID", _gameId.Value);
                        cmd.Parameters.AddWithValue("@GameName", txtGameName.Text);
                        cmd.Parameters.AddWithValue("@Developer", txtDeveloper.Text);
                        cmd.Parameters.AddWithValue("@ReleaseDate", dpReleaseDate.SelectedDate.Value);
                        cmd.Parameters.AddWithValue("@MaxPlayers", maxPlayers);
                        cmd.Parameters.AddWithValue("@IsActive", chkIsActive.IsChecked ?? false);

                        cmd.ExecuteNonQuery();
                    }
                }
                else
                {
                    string insertQuery = @"
                        INSERT INTO Games 
                            (GameName, Developer, ReleaseDate, MaxPlayersPerTeam, IsActive) 
                        VALUES 
                            (@GameName, @Developer, @ReleaseDate, @MaxPlayers, @IsActive)";

                    using (SqlCommand cmd = new SqlCommand(insertQuery, App.Connection))
                    {
                        cmd.Parameters.AddWithValue("@GameName", txtGameName.Text);
                        cmd.Parameters.AddWithValue("@Developer", txtDeveloper.Text);
                        cmd.Parameters.AddWithValue("@ReleaseDate", dpReleaseDate.SelectedDate.Value);
                        cmd.Parameters.AddWithValue("@MaxPlayers", maxPlayers);
                        cmd.Parameters.AddWithValue("@IsActive", chkIsActive.IsChecked ?? false);

                        cmd.ExecuteNonQuery();
                    }
                }

                DialogResult = true;
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при сохранении игры: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }
}
