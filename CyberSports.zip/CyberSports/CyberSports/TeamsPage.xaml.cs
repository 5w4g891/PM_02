﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CyberSports
{
    /// <summary>
    /// Логика взаимодействия для TeamsPage.xaml
    /// </summary>
    public partial class TeamsPage : Page
    {
        public TeamsPage()
        {
            InitializeComponent();
            LoadTeams();
        }

        private void LoadTeams()
        {
            try
            {
                string query = "SELECT TeamID, TeamName, Tag, Country, CreationDate, IsActive FROM Teams ORDER BY TeamName";

                using (SqlCommand cmd = new SqlCommand(query, App.Connection))
                {
                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                    TeamsGrid.ItemsSource = dt.DefaultView;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке команд: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void AddTeam_Click(object sender, RoutedEventArgs e)
        {
            TeamEditWindow editWindow = new TeamEditWindow();
            if (editWindow.ShowDialog() == true)
            {
                LoadTeams();
            }
        }

        private void EditTeam_Click(object sender, RoutedEventArgs e)
        {
            if (TeamsGrid.SelectedItem == null)
            {
                MessageBox.Show("Выберите команду для редактирования", "Информация", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            DataRowView row = (DataRowView)TeamsGrid.SelectedItem;
            int teamId = (int)row["TeamID"];

            TeamEditWindow editWindow = new TeamEditWindow(teamId);
            if (editWindow.ShowDialog() == true)
            {
                LoadTeams();
            }
        }

        private void DeleteTeam_Click(object sender, RoutedEventArgs e)
        {
            if (TeamsGrid.SelectedItem == null)
            {
                MessageBox.Show("Выберите команду для удаления", "Информация", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            DataRowView row = (DataRowView)TeamsGrid.SelectedItem;
            int teamId = (int)row["TeamID"];
            string teamName = row["TeamName"].ToString();

            if (MessageBox.Show($"Вы уверены, что хотите удалить команду '{teamName}'?",
                "Подтверждение удаления", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    string query = "UPDATE Teams SET IsActive = 0 WHERE TeamID = @TeamID";
                    using (SqlCommand cmd = new SqlCommand(query, App.Connection))
                    {
                        cmd.Parameters.AddWithValue("@TeamID", teamId);
                        cmd.ExecuteNonQuery();
                    }

                    MessageBox.Show("Команда успешно деактивирована", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                    LoadTeams();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при удалении команды: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void SearchTeams(object sender, System.Windows.Input.KeyEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtSearch.Text))
            {
                LoadTeams();
                return;
            }

            try
            {
                string query = @"
                    SELECT TeamID, TeamName, Tag, Country, CreationDate, IsActive 
                    FROM Teams 
                    WHERE TeamName LIKE @Search OR Tag LIKE @Search
                    ORDER BY TeamName";

                using (SqlCommand cmd = new SqlCommand(query, App.Connection))
                {
                    cmd.Parameters.AddWithValue("@Search", $"%{txtSearch.Text}%");

                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                    TeamsGrid.ItemsSource = dt.DefaultView;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при поиске команд: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
