﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows;
using System.Windows.Controls;

namespace CyberSports
{
    public partial class PlayerEditWindow : Window
    {
        private int? _playerId;

        public PlayerEditWindow(int? playerId = null)
        {
            InitializeComponent();
            _playerId = playerId;

            LoadTeams();

            if (_playerId.HasValue)
            {
                LoadPlayerData();
            }
        }

        private void LoadTeams()
        {
            try
            {
                string query = "SELECT TeamID, TeamName FROM Teams WHERE IsActive = 1 ORDER BY TeamName";

                using (SqlCommand cmd = new SqlCommand(query, App.Connection))
                {
                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                    cmbTeams.ItemsSource = dt.DefaultView;
                    cmbTeams.DisplayMemberPath = "TeamName";
                    cmbTeams.SelectedValuePath = "TeamID";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке команд: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void LoadPlayerData()
        {
            try
            {
                string query = "SELECT Nickname, TeamID, Position, IsCaptain FROM Players WHERE PlayerID = @PlayerID";

                using (SqlCommand cmd = new SqlCommand(query, App.Connection))
                {
                    cmd.Parameters.AddWithValue("@PlayerID", _playerId.Value);

                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            txtNickname.Text = reader["Nickname"].ToString();
                            cmbTeams.SelectedValue = reader["TeamID"];
                            txtPosition.Text = reader["Position"].ToString();
                            chkIsCaptain.IsChecked = (bool)reader["IsCaptain"];
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке данных игрока: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtNickname.Text))
            {
                MessageBox.Show("Введите никнейм игрока", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (cmbTeams.SelectedValue == null)
            {
                MessageBox.Show("Выберите команду", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                int teamId = (int)cmbTeams.SelectedValue;

                if (_playerId.HasValue)
                {
                    string updateQuery = @"
                        UPDATE Players 
                        SET Nickname = @Nickname,
                            TeamID = @TeamID,
                            Position = @Position,
                            IsCaptain = @IsCaptain
                        WHERE PlayerID = @PlayerID";

                    using (SqlCommand cmd = new SqlCommand(updateQuery, App.Connection))
                    {
                        cmd.Parameters.AddWithValue("@PlayerID", _playerId.Value);
                        cmd.Parameters.AddWithValue("@Nickname", txtNickname.Text);
                        cmd.Parameters.AddWithValue("@TeamID", teamId);
                        cmd.Parameters.AddWithValue("@Position", txtPosition.Text);
                        cmd.Parameters.AddWithValue("@IsCaptain", chkIsCaptain.IsChecked ?? false);

                        cmd.ExecuteNonQuery();
                    }
                }
                else
                {
                    string insertQuery = @"
                        INSERT INTO Players 
                            (UserID, TeamID, Nickname, JoinDate, IsCaptain, Position) 
                        VALUES 
                            (1, @TeamID, @Nickname, GETDATE(), @IsCaptain, @Position)";

                    using (SqlCommand cmd = new SqlCommand(insertQuery, App.Connection))
                    {
                        cmd.Parameters.AddWithValue("@TeamID", teamId);
                        cmd.Parameters.AddWithValue("@Nickname", txtNickname.Text);
                        cmd.Parameters.AddWithValue("@IsCaptain", chkIsCaptain.IsChecked ?? false);
                        cmd.Parameters.AddWithValue("@Position", txtPosition.Text);

                        cmd.ExecuteNonQuery();
                    }
                }

                DialogResult = true;
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при сохранении игрока: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }
}
