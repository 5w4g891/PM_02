﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CyberSports
{
    /// <summary>
    /// Логика взаимодействия для TeamEditWindow.xaml
    /// </summary>
    public partial class TeamEditWindow : Window
    {
        private int? _teamId;
        private readonly string[] _countries = new[] { "Россия", "США", "Китай", "Корея", "Япония", "Германия", "Франция", "Великобритания" };

        public TeamEditWindow(int? teamId = null)
        {
            InitializeComponent();
            _teamId = teamId;

            // Заполняем список стран
            cmbCountry.ItemsSource = _countries;

            if (_teamId.HasValue)
            {
                LoadTeamData();
            }
        }

        private void LoadTeamData()
        {
            try
            {
                string query = "SELECT TeamName, Tag, Country FROM Teams WHERE TeamID = @TeamID";

                using (SqlCommand cmd = new SqlCommand(query, App.Connection))
                {
                    cmd.Parameters.AddWithValue("@TeamID", _teamId.Value);

                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            txtTeamName.Text = reader["TeamName"].ToString();
                            txtTag.Text = reader["Tag"].ToString();
                            cmbCountry.SelectedItem = reader["Country"].ToString();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке данных команды: {ex.Message}", "Ошибка",
                              MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtTeamName.Text))
            {
                MessageBox.Show("Введите название команды", "Ошибка",
                                MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (string.IsNullOrWhiteSpace(txtTag.Text))
            {
                MessageBox.Show("Введите тег команды", "Ошибка",
                                MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (cmbCountry.SelectedItem == null)
            {
                MessageBox.Show("Выберите страну", "Ошибка",
                                MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                if (_teamId.HasValue)
                {
                    // Обновление существующей команды
                    string updateQuery = @"
                        UPDATE Teams 
                        SET TeamName = @TeamName,
                            Tag = @Tag,
                            Country = @Country
                        WHERE TeamID = @TeamID";

                    using (SqlCommand cmd = new SqlCommand(updateQuery, App.Connection))
                    {
                        cmd.Parameters.AddWithValue("@TeamID", _teamId.Value);
                        cmd.Parameters.AddWithValue("@TeamName", txtTeamName.Text);
                        cmd.Parameters.AddWithValue("@Tag", txtTag.Text);
                        cmd.Parameters.AddWithValue("@Country", cmbCountry.SelectedItem.ToString());

                        cmd.ExecuteNonQuery();
                    }
                }
                else
                {
                    // Добавление новой команды
                    string insertQuery = @"
                        INSERT INTO Teams 
                            (TeamName, Tag, Country, CreationDate, IsActive) 
                        VALUES 
                            (@TeamName, @Tag, @Country, GETDATE(), 1)";

                    using (SqlCommand cmd = new SqlCommand(insertQuery, App.Connection))
                    {
                        cmd.Parameters.AddWithValue("@TeamName", txtTeamName.Text);
                        cmd.Parameters.AddWithValue("@Tag", txtTag.Text);
                        cmd.Parameters.AddWithValue("@Country", cmbCountry.SelectedItem.ToString());

                        cmd.ExecuteNonQuery();
                    }
                }

                DialogResult = true;
                Close();
            }
            catch (SqlException ex) when (ex.Number == 2627 || ex.Number == 2601)
            {
                MessageBox.Show("Команда с таким названием или тегом уже существует",
                              "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при сохранении команды: {ex.Message}",
                              "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }
}
