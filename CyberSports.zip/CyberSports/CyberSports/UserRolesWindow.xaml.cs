﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CyberSports
{
    /// <summary>
    /// Логика взаимодействия для UserRolesWindow.xaml
    /// </summary>
    public partial class UserRolesWindow : Window
    {
        private readonly int _userId;
        private readonly string _username;
        private readonly List<UserRole> _userRoles = new List<UserRole>();

        public string UserInfo => $"Пользователь: {_username} (ID: {_userId})";

        public UserRolesWindow(int userId, string username)
        {
            InitializeComponent();
            _userId = userId;
            _username = username;
            DataContext = this;
            LoadRoles();
        }

        private void LoadRoles()
        {
            try
            {
                // Загружаем все доступные роли
                string allRolesQuery = "SELECT RoleID, RoleName FROM Roles";
                DataTable allRolesTable = new DataTable();

                using (SqlCommand cmd = new SqlCommand(allRolesQuery, App.Connection))
                {
                    new SqlDataAdapter(cmd).Fill(allRolesTable);
                }

                // Загружаем роли пользователя
                string userRolesQuery = "SELECT RoleID FROM UserRoles WHERE UserID = @UserID";
                List<int> userRoleIds = new List<int>();

                using (SqlCommand cmd = new SqlCommand(userRolesQuery, App.Connection))
                {
                    cmd.Parameters.AddWithValue("@UserID", _userId);
                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            userRoleIds.Add(reader.GetInt32(0));
                        }
                    }
                }

                // Формируем список ролей с флагами назначения
                foreach (DataRow row in allRolesTable.Rows)
                {
                    _userRoles.Add(new UserRole
                    {
                        RoleID = row.Field<int>("RoleID"),
                        RoleName = row.Field<string>("RoleName"),
                        IsAssigned = userRoleIds.Contains(row.Field<int>("RoleID"))
                    });
                }

                RolesList.ItemsSource = _userRoles;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке ролей: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                using (var transaction = App.Connection.BeginTransaction())
                {
                    try
                    {
                        // Удаляем все текущие роли пользователя
                        string deleteQuery = "DELETE FROM UserRoles WHERE UserID = @UserID";
                        using (SqlCommand cmd = new SqlCommand(deleteQuery, App.Connection, transaction))
                        {
                            cmd.Parameters.AddWithValue("@UserID", _userId);
                            cmd.ExecuteNonQuery();
                        }

                        // Добавляем выбранные роли
                        string insertQuery = "INSERT INTO UserRoles (UserID, RoleID) VALUES (@UserID, @RoleID)";
                        foreach (var role in _userRoles.Where(r => r.IsAssigned))
                        {
                            using (SqlCommand cmd = new SqlCommand(insertQuery, App.Connection, transaction))
                            {
                                cmd.Parameters.AddWithValue("@UserID", _userId);
                                cmd.Parameters.AddWithValue("@RoleID", role.RoleID);
                                cmd.ExecuteNonQuery();
                            }
                        }

                        transaction.Commit();
                        MessageBox.Show("Роли успешно обновлены", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                        DialogResult = true;
                    }
                    catch
                    {
                        transaction.Rollback();
                        throw;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при сохранении ролей: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }

    public class UserRole
    {
        public int RoleID { get; set; }
        public string RoleName { get; set; }
        public bool IsAssigned { get; set; }
    }
}
