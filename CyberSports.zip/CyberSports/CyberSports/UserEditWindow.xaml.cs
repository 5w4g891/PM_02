﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CyberSports
{
    /// <summary>
    /// Логика взаимодействия для UserEditWindow.xaml
    /// </summary>
    public partial class UserEditWindow : Window
    {
        private int? _userId;
        public UserEditWindow(int? userId = null)
        {
            InitializeComponent();
            _userId = userId;

            if (_userId.HasValue)
            {
                LoadUserData();
            }
            else
            {
                chkIsActive.IsChecked = true;
            }
        }

        private void LoadUserData()
        {
            try
            {
                string query = "SELECT Username, Email, FirstName, LastName, IsActive FROM Users WHERE UserID = @UserID";

                using (SqlCommand cmd = new SqlCommand(query, App.Connection))
                {
                    cmd.Parameters.AddWithValue("@UserID", _userId.Value);

                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            txtUsername.Text = reader["Username"].ToString();
                            txtEmail.Text = reader["Email"].ToString();
                            txtFirstName.Text = reader["FirstName"].ToString();
                            txtLastName.Text = reader["LastName"].ToString();
                            chkIsActive.IsChecked = (bool)reader["IsActive"];
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке данных пользователя: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtUsername.Text))
            {
                MessageBox.Show("Введите логин пользователя", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (string.IsNullOrWhiteSpace(txtEmail.Text))
            {
                MessageBox.Show("Введите email пользователя", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                if (_userId.HasValue)
                {
                    // Обновление существующего пользователя
                    string updateQuery = @"
                        UPDATE Users 
                        SET Username = @Username,
                            Email = @Email,
                            FirstName = @FirstName,
                            LastName = @LastName,
                            IsActive = @IsActive
                        WHERE UserID = @UserID";

                    using (SqlCommand cmd = new SqlCommand(updateQuery, App.Connection))
                    {
                        cmd.Parameters.AddWithValue("@UserID", _userId.Value);
                        cmd.Parameters.AddWithValue("@Username", txtUsername.Text);
                        cmd.Parameters.AddWithValue("@Email", txtEmail.Text);
                        cmd.Parameters.AddWithValue("@FirstName", txtFirstName.Text);
                        cmd.Parameters.AddWithValue("@LastName", txtLastName.Text);
                        cmd.Parameters.AddWithValue("@IsActive", chkIsActive.IsChecked ?? false);

                        cmd.ExecuteNonQuery();
                    }
                }
                else
                {
                    // Добавление нового пользователя
                    string insertQuery = @"
                        INSERT INTO Users 
                            (Username, Email, FirstName, LastName, IsActive, RegistrationDate) 
                        VALUES 
                            (@Username, @Email, @FirstName, @LastName, @IsActive, GETDATE())";

                    using (SqlCommand cmd = new SqlCommand(insertQuery, App.Connection))
                    {
                        cmd.Parameters.AddWithValue("@Username", txtUsername.Text);
                        cmd.Parameters.AddWithValue("@Email", txtEmail.Text);
                        cmd.Parameters.AddWithValue("@FirstName", txtFirstName.Text);
                        cmd.Parameters.AddWithValue("@LastName", txtLastName.Text);
                        cmd.Parameters.AddWithValue("@IsActive", chkIsActive.IsChecked ?? false);

                        cmd.ExecuteNonQuery();
                    }
                }

                DialogResult = true;
                Close();
            }
            catch (SqlException ex) when (ex.Number == 2627 || ex.Number == 2601)
            {
                MessageBox.Show("Пользователь с таким логином или email уже существует", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при сохранении пользователя: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }
}
