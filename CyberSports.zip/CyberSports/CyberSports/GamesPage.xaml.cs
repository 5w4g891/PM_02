﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CyberSports
{
    /// <summary>
    /// Логика взаимодействия для GamesPage.xaml
    /// </summary>
    public partial class GamesPage : Page  // Наследование от Page
    {
        public GamesPage()
        {
            InitializeComponent();
            LoadGames();
        }

        private void LoadGames()
        {
            try
            {
                string query = "SELECT GameID, GameName, Developer, ReleaseDate, MaxPlayersPerTeam, IsActive FROM Games ORDER BY GameName";

                using (SqlCommand cmd = new SqlCommand(query, App.Connection))
                {
                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                    GamesGrid.ItemsSource = dt.DefaultView;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке игр: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void AddGame_Click(object sender, RoutedEventArgs e)
        {
            GameEditWindow editWindow = new GameEditWindow();
            if (editWindow.ShowDialog() == true)
            {
                LoadGames();
            }
        }

        private void EditGame_Click(object sender, RoutedEventArgs e)
        {
            if (GamesGrid.SelectedItem == null)
            {
                MessageBox.Show("Выберите игру для редактирования", "Информация", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            DataRowView row = (DataRowView)GamesGrid.SelectedItem;
            int gameId = (int)row["GameID"];

            GameEditWindow editWindow = new GameEditWindow(gameId);
            if (editWindow.ShowDialog() == true)
            {
                LoadGames();
            }
        }

        private void ActivateGame_Click(object sender, RoutedEventArgs e)
        {
            if (GamesGrid.SelectedItem == null)
            {
                MessageBox.Show("Выберите игру для активации", "Информация", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            DataRowView row = (DataRowView)GamesGrid.SelectedItem;
            int gameId = (int)row["GameID"];
            string gameName = row["GameName"].ToString();

            if (MessageBox.Show($"Вы уверены, что хотите активировать игру '{gameName}'?",
                "Подтверждение активации", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    string query = "UPDATE Games SET IsActive = 1 WHERE GameID = @GameID";
                    using (SqlCommand cmd = new SqlCommand(query, App.Connection))
                    {
                        cmd.Parameters.AddWithValue("@GameID", gameId);
                        cmd.ExecuteNonQuery();
                    }

                    MessageBox.Show("Игра успешно активирована", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                    LoadGames();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при активации игры: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void DeactivateGame_Click(object sender, RoutedEventArgs e)
        {
            if (GamesGrid.SelectedItem == null)
            {
                MessageBox.Show("Выберите игру для деактивации", "Информация", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            DataRowView row = (DataRowView)GamesGrid.SelectedItem;
            int gameId = (int)row["GameID"];
            string gameName = row["GameName"].ToString();

            if (MessageBox.Show($"Вы уверены, что хотите деактивировать игру '{gameName}'?",
                "Подтверждение деактивации", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    string query = "UPDATE Games SET IsActive = 0 WHERE GameID = @GameID";
                    using (SqlCommand cmd = new SqlCommand(query, App.Connection))
                    {
                        cmd.Parameters.AddWithValue("@GameID", gameId);
                        cmd.ExecuteNonQuery();
                    }

                    MessageBox.Show("Игра успешно деактивирована", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                    LoadGames();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при деактивации игры: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void SearchGames(object sender, System.Windows.Input.KeyEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtSearch.Text))
            {
                LoadGames();
                return;
            }

            try
            {
                string query = @"
                    SELECT GameID, GameName, Developer, ReleaseDate, MaxPlayersPerTeam, IsActive 
                    FROM Games 
                    WHERE GameName LIKE @Search OR Developer LIKE @Search
                    ORDER BY GameName";

                using (SqlCommand cmd = new SqlCommand(query, App.Connection))
                {
                    cmd.Parameters.AddWithValue("@Search", $"%{txtSearch.Text}%");

                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                    GamesGrid.ItemsSource = dt.DefaultView;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при поиске игр: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
