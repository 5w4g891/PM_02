﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CyberSports
{
    /// <summary>
    /// Логика взаимодействия для MatchResultWindow.xaml
    /// </summary>
    public partial class MatchResultWindow : Window
    {
        private readonly int _matchId;

        public MatchResultWindow(int matchId)
        {
            InitializeComponent();
            _matchId = matchId;
            LoadMatchData();
        }

        private void LoadMatchData()
        {
            try
            {
                string query = @"
                    SELECT 
                        t1.TeamName AS Team1Name,
                        t2.TeamName AS Team2Name,
                        mp1.Score AS Score1,
                        mp2.Score AS Score2
                    FROM Matches m
                    JOIN MatchParticipants mp1 ON m.MatchID = mp1.MatchID AND mp1.ParticipantOrder = 1
                    JOIN Teams t1 ON mp1.TeamID = t1.TeamID
                    JOIN MatchParticipants mp2 ON m.MatchID = mp2.MatchID AND mp2.ParticipantOrder = 2
                    JOIN Teams t2 ON mp2.TeamID = t2.TeamID
                    WHERE m.MatchID = @MatchID";

                using (SqlCommand cmd = new SqlCommand(query, App.Connection))
                {
                    cmd.Parameters.AddWithValue("@MatchID", _matchId);

                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            cmbTeam1.Items.Add(reader["Team1Name"].ToString());
                            cmbTeam1.SelectedIndex = 0;

                            cmbTeam2.Items.Add(reader["Team2Name"].ToString());
                            cmbTeam2.SelectedIndex = 0;

                            txtScore1.Text = reader["Score1"]?.ToString() ?? "0";
                            txtScore2.Text = reader["Score2"]?.ToString() ?? "0";
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке данных матча: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            if (!int.TryParse(txtScore1.Text, out int score1) || score1 < 0)
            {
                MessageBox.Show("Введите корректный счет для команды 1", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (!int.TryParse(txtScore2.Text, out int score2) || score2 < 0)
            {
                MessageBox.Show("Введите корректный счет для команды 2", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                // Обновляем счет в базе данных
                string updateQuery = @"
                    UPDATE MatchParticipants SET Score = @Score1 
                    WHERE MatchID = @MatchID AND ParticipantOrder = 1;
                    
                    UPDATE MatchParticipants SET Score = @Score2 
                    WHERE MatchID = @MatchID AND ParticipantOrder = 2;
                    
                    UPDATE Matches SET Status = 'Completed' 
                    WHERE MatchID = @MatchID";

                using (SqlCommand cmd = new SqlCommand(updateQuery, App.Connection))
                {
                    cmd.Parameters.AddWithValue("@MatchID", _matchId);
                    cmd.Parameters.AddWithValue("@Score1", score1);
                    cmd.Parameters.AddWithValue("@Score2", score2);

                    cmd.ExecuteNonQuery();
                }

                DialogResult = true;
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при сохранении результата: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        private void txtScore1_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            e.Handled = !char.IsDigit(e.Text, 0);

        }


        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }
}

