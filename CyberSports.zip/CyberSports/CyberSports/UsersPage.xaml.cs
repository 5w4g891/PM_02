﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CyberSports
{
    /// <summary>
    /// Логика взаимодействия для UsersPage.xaml
    /// </summary>
    public partial class UsersPage : Page
    {
        public UsersPage()
        {
            InitializeComponent();
            LoadUsers();
        }

        private void LoadUsers()
        {
            try
            {
                string query = "SELECT UserID, Username, Email, FirstName, LastName, RegistrationDate, IsActive FROM Users ORDER BY Username";

                using (SqlCommand cmd = new SqlCommand(query, App.Connection))
                {
                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                    UsersGrid.ItemsSource = dt.DefaultView;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке пользователей: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void SearchUsers(object sender, KeyEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtSearch.Text))
            {
                LoadUsers();
                return;
            }

            try
            {
                string query = @"
                    SELECT UserID, Username, Email, FirstName, LastName, RegistrationDate, IsActive 
                    FROM Users 
                    WHERE Username LIKE @Search OR Email LIKE @Search OR FirstName LIKE @Search OR LastName LIKE @Search
                    ORDER BY Username";

                using (SqlCommand cmd = new SqlCommand(query, App.Connection))
                {
                    cmd.Parameters.AddWithValue("@Search", $"%{txtSearch.Text}%");

                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                    UsersGrid.ItemsSource = dt.DefaultView;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при поиске пользователей: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void AddUser_Click(object sender, RoutedEventArgs e)
        {
            UserEditWindow editWindow = new UserEditWindow();
            if (editWindow.ShowDialog() == true)
            {
                LoadUsers();
            }
        }

        private void EditUser_Click(object sender, RoutedEventArgs e)
        {
            if (UsersGrid.SelectedItem == null)
            {
                MessageBox.Show("Выберите пользователя для редактирования", "Информация", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            DataRowView row = (DataRowView)UsersGrid.SelectedItem;
            int userId = (int)row["UserID"];

            UserEditWindow editWindow = new UserEditWindow(userId);
            if (editWindow.ShowDialog() == true)
            {
                LoadUsers();
            }
        }

        private void ActivateUser_Click(object sender, RoutedEventArgs e)
        {
            if (UsersGrid.SelectedItem == null)
            {
                MessageBox.Show("Выберите пользователя для активации", "Информация", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            DataRowView row = (DataRowView)UsersGrid.SelectedItem;
            int userId = (int)row["UserID"];
            string username = row["Username"].ToString();

            if (MessageBox.Show($"Активировать пользователя '{username}'?", "Подтверждение", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    string query = "UPDATE Users SET IsActive = 1 WHERE UserID = @UserID";
                    using (SqlCommand cmd = new SqlCommand(query, App.Connection))
                    {
                        cmd.Parameters.AddWithValue("@UserID", userId);
                        cmd.ExecuteNonQuery();
                    }
                    LoadUsers();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при активации пользователя: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void DeactivateUser_Click(object sender, RoutedEventArgs e)
        {
            if (UsersGrid.SelectedItem == null)
            {
                MessageBox.Show("Выберите пользователя для деактивации", "Информация", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            DataRowView row = (DataRowView)UsersGrid.SelectedItem;
            int userId = (int)row["UserID"];
            string username = row["Username"].ToString();

            if (MessageBox.Show($"Деактивировать пользователя '{username}'?", "Подтверждение", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    string query = "UPDATE Users SET IsActive = 0 WHERE UserID = @UserID";
                    using (SqlCommand cmd = new SqlCommand(query, App.Connection))
                    {
                        cmd.Parameters.AddWithValue("@UserID", userId);
                        cmd.ExecuteNonQuery();
                    }
                    LoadUsers();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при деактивации пользователя: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void AssignRoles_Click(object sender, RoutedEventArgs e)
        {
            if (UsersGrid.SelectedItem == null)
            {
                MessageBox.Show("Выберите пользователя для назначения ролей", "Информация", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            DataRowView row = (DataRowView)UsersGrid.SelectedItem;
            int userId = (int)row["UserID"];
            string username = row["Username"].ToString();

            UserRolesWindow rolesWindow = new UserRolesWindow(userId, username);
            rolesWindow.ShowDialog();
            LoadUsers();
        }
    }
}