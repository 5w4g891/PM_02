﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows;
using System.Windows.Controls;

namespace CyberSports
{
    public partial class MatchEditWindow : Window
    {
        private int? _matchId;
        private int _tournamentId;

        public MatchEditWindow(int? matchId = null, int? tournamentId = null)
        {
            InitializeComponent();
            _matchId = matchId;
            _tournamentId = tournamentId ?? 0;

            LoadTournaments();

            if (_matchId.HasValue)
            {
                LoadMatchData();

                // Проверка статуса матча
                string statusQuery = "SELECT Status FROM Matches WHERE MatchID = @MatchID";
                using (SqlCommand cmd = new SqlCommand(statusQuery, App.Connection))
                {
                    cmd.Parameters.AddWithValue("@MatchID", _matchId.Value);
                    string status = cmd.ExecuteScalar()?.ToString();

                    if (status == "Completed")
                    {
                        MessageBox.Show("Этот матч уже завершен и не может быть изменен",
                                      "Информация", MessageBoxButton.OK, MessageBoxImage.Information);
                        this.IsEnabled = false; // Делаем окно неактивным
                    }
                }
            }
            else
            {
                dpMatchDate.SelectedDate = DateTime.Now;
            }
        }

        private void LoadTournaments()
        {
            try
            {
                string query = "SELECT TournamentID, TournamentName FROM Tournaments ORDER BY StartDate DESC";

                using (SqlCommand cmd = new SqlCommand(query, App.Connection))
                {
                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                    cmbTournaments.ItemsSource = dt.DefaultView;
                    cmbTournaments.DisplayMemberPath = "TournamentName";
                    cmbTournaments.SelectedValuePath = "TournamentID";

                    if (_tournamentId > 0)
                    {
                        cmbTournaments.SelectedValue = _tournamentId;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке турниров: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void LoadMatchData()
        {
            try
            {
                string query = "SELECT TournamentID, RoundNumber, MatchNumber, StartTime FROM Matches WHERE MatchID = @MatchID";

                using (SqlCommand cmd = new SqlCommand(query, App.Connection))
                {
                    cmd.Parameters.AddWithValue("@MatchID", _matchId.Value);

                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            cmbTournaments.SelectedValue = (int)reader["TournamentID"];
                            txtRoundNumber.Text = reader["RoundNumber"].ToString();
                            txtMatchNumber.Text = reader["MatchNumber"].ToString();
                            dpMatchDate.SelectedDate = (DateTime)reader["StartTime"];
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке данных матча: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            if (cmbTournaments.SelectedValue == null)
            {
                MessageBox.Show("Выберите турнир", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (!int.TryParse(txtRoundNumber.Text, out int roundNumber) || roundNumber <= 0)
            {
                MessageBox.Show("Введите корректный номер раунда", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (!int.TryParse(txtMatchNumber.Text, out int matchNumber) || matchNumber <= 0)
            {
                MessageBox.Show("Введите корректный номер матча", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (!dpMatchDate.SelectedDate.HasValue)
            {
                MessageBox.Show("Выберите дату матча", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                int tournamentId = (int)cmbTournaments.SelectedValue;

                if (_matchId.HasValue)
                {
                    string updateQuery = @"
                        UPDATE Matches 
                        SET TournamentID = @TournamentID,
                            RoundNumber = @RoundNumber,
                            MatchNumber = @MatchNumber,
                            StartTime = @StartTime
                        WHERE MatchID = @MatchID";

                    using (SqlCommand cmd = new SqlCommand(updateQuery, App.Connection))
                    {
                        cmd.Parameters.AddWithValue("@MatchID", _matchId.Value);
                        cmd.Parameters.AddWithValue("@TournamentID", tournamentId);
                        cmd.Parameters.AddWithValue("@RoundNumber", roundNumber);
                        cmd.Parameters.AddWithValue("@MatchNumber", matchNumber);
                        cmd.Parameters.AddWithValue("@StartTime", dpMatchDate.SelectedDate.Value);

                        cmd.ExecuteNonQuery();
                    }
                }
                else
                {
                    string insertQuery = @"
                        INSERT INTO Matches 
                            (TournamentID, RoundNumber, MatchNumber, StartTime, Status) 
                        VALUES 
                            (@TournamentID, @RoundNumber, @MatchNumber, @StartTime, 'Scheduled')";

                    using (SqlCommand cmd = new SqlCommand(insertQuery, App.Connection))
                    {
                        cmd.Parameters.AddWithValue("@TournamentID", tournamentId);
                        cmd.Parameters.AddWithValue("@RoundNumber", roundNumber);
                        cmd.Parameters.AddWithValue("@MatchNumber", matchNumber);
                        cmd.Parameters.AddWithValue("@StartTime", dpMatchDate.SelectedDate.Value);

                        cmd.ExecuteNonQuery();
                    }
                }

                DialogResult = true;
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при сохранении матча: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }
}
