﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CyberSports
{
    /// <summary>
    /// Логика взаимодействия для TournamentEditWindow.xaml
    /// </summary>
    public partial class TournamentEditWindow : Window
    {
        private int? _tournamentId;
        public TournamentEditWindow(int? tournamentId = null)
        {
            InitializeComponent();
            _tournamentId = tournamentId;
            LoadGames();

            if (_tournamentId.HasValue)
            {
                LoadTournamentData();
            }
            else
            {
                dpStartDate.SelectedDate = DateTime.Today;
                dpEndDate.SelectedDate = DateTime.Today.AddDays(7);
            }
        }

        private void LoadGames()
        {
            try
            {
                string query = "SELECT GameID, GameName FROM Games WHERE IsActive = 1 ORDER BY GameName";
                using (SqlCommand cmd = new SqlCommand(query, App.Connection))
                {
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        cmbGames.Items.Add(new
                        {
                            GameID = reader["GameID"],
                            GameName = reader["GameName"].ToString()
                        });
                    }
                    reader.Close();
                }

                if (cmbGames.Items.Count > 0)
                    cmbGames.DisplayMemberPath = "GameName";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке списка игр: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void LoadTournamentData()
        {
            try
            {
                string query = "SELECT TournamentName, GameID, StartDate, EndDate FROM Tournaments WHERE TournamentID = @TournamentID";
                using (SqlCommand cmd = new SqlCommand(query, App.Connection))
                {
                    cmd.Parameters.AddWithValue("@TournamentID", _tournamentId.Value);

                    SqlDataReader reader = cmd.ExecuteReader();
                    if (reader.Read())
                    {
                        txtName.Text = reader["TournamentName"].ToString();
                        dpStartDate.SelectedDate = (DateTime)reader["StartDate"];
                        dpEndDate.SelectedDate = (DateTime)reader["EndDate"];

                        // Установка выбранной игры
                        int gameId = (int)reader["GameID"];
                        foreach (var item in cmbGames.Items)
                        {
                            dynamic game = item;
                            if (game.GameID == gameId)
                            {
                                cmbGames.SelectedItem = item;
                                break;
                            }
                        }
                    }
                    reader.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке данных турнира: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtName.Text))
            {
                MessageBox.Show("Введите название турнира", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (cmbGames.SelectedItem == null)
            {
                MessageBox.Show("Выберите игру", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (!dpStartDate.SelectedDate.HasValue || !dpEndDate.SelectedDate.HasValue)
            {
                MessageBox.Show("Укажите даты начала и окончания", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (dpStartDate.SelectedDate.Value > dpEndDate.SelectedDate.Value)
            {
                MessageBox.Show("Дата начала не может быть позже даты окончания", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                dynamic selectedGame = cmbGames.SelectedItem;
                int gameId = selectedGame.GameID;

                if (_tournamentId.HasValue)
                {
                    // Обновление существующего турнира
                    string updateQuery = @"
                        UPDATE Tournaments 
                        SET TournamentName = @Name, 
                            GameID = @GameID, 
                            StartDate = @StartDate, 
                            EndDate = @EndDate
                        WHERE TournamentID = @TournamentID";

                    using (SqlCommand cmd = new SqlCommand(updateQuery, App.Connection))
                    {
                        cmd.Parameters.AddWithValue("@TournamentID", _tournamentId.Value);
                        cmd.Parameters.AddWithValue("@Name", txtName.Text);
                        cmd.Parameters.AddWithValue("@GameID", gameId);
                        cmd.Parameters.AddWithValue("@StartDate", dpStartDate.SelectedDate.Value);
                        cmd.Parameters.AddWithValue("@EndDate", dpEndDate.SelectedDate.Value);

                        cmd.ExecuteNonQuery();
                    }
                }
                else
                {
                    // Добавление нового турнира
                    string insertQuery = @"
                        INSERT INTO Tournaments 
                            (TournamentName, GameID, StartDate, EndDate, OrganizerID) 
                        VALUES 
                            (@Name, @GameID, @StartDate, @EndDate, 1)";

                    using (SqlCommand cmd = new SqlCommand(insertQuery, App.Connection))
                    {
                        cmd.Parameters.AddWithValue("@Name", txtName.Text);
                        cmd.Parameters.AddWithValue("@GameID", gameId);
                        cmd.Parameters.AddWithValue("@StartDate", dpStartDate.SelectedDate.Value);
                        cmd.Parameters.AddWithValue("@EndDate", dpEndDate.SelectedDate.Value);

                        cmd.ExecuteNonQuery();
                    }
                }

                DialogResult = true;
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при сохранении турнира: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }
}
