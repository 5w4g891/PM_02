﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace CyberSports
{
    public static class NotificationService
    {
        private static int _currentUserID;
        private static string _currentUsername;
        private static bool _isAdmin;

        public static int CurrentUserID
        {
            get => _currentUserID;
            private set => _currentUserID = value;
        }

        public static string CurrentUsername
        {
            get => _currentUsername;
            private set => _currentUsername = value;
        }

        public static bool IsAdmin
        {
            get => _isAdmin;
            private set => _isAdmin = value;
        }

        public static void CheckAndShowNotifications()
        {
            if (CurrentUserID == 0) return; // Проверяем на 0 вместо HasValue

            try
            {
                string query = @"
                    SELECT n.NotificationID, n.Message, n.CreatedDate
                    FROM Notifications n
                    WHERE n.UserID = @UserID AND n.IsRead = 0
                    ORDER BY n.CreatedDate DESC";

                using (SqlCommand cmd = new SqlCommand(query, App.Connection))
                {
                    cmd.Parameters.AddWithValue("@UserID", CurrentUserID); // Используем напрямую

                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            string message = reader["Message"].ToString();
                            DateTime createdDate = (DateTime)reader["CreatedDate"];

                            MessageBox.Show(message, $"Уведомление от {createdDate:dd.MM.yyyy HH:mm}",
                                          MessageBoxButton.OK, MessageBoxImage.Information);
                        }
                    }
                }

                MarkNotificationsAsRead();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при проверке уведомлений: {ex.Message}", "Ошибка",
                                MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private static void MarkNotificationsAsRead()
        {
            string query = "UPDATE Notifications SET IsRead = 1 WHERE UserID = @UserID AND IsRead = 0";

            using (SqlCommand cmd = new SqlCommand(query, App.Connection))
            {
                cmd.Parameters.AddWithValue("@UserID", CurrentUserID); // Используем напрямую
                cmd.ExecuteNonQuery();
            }
        }

        public static void SendNotification(int userId, string message)
        {
            try
            {
                string query = @"
                    INSERT INTO Notifications 
                        (UserID, Message, CreatedDate, IsRead) 
                    VALUES 
                        (@UserID, @Message, GETDATE(), 0)";

                using (SqlCommand cmd = new SqlCommand(query, App.Connection))
                {
                    cmd.Parameters.AddWithValue("@UserID", userId);
                    cmd.Parameters.AddWithValue("@Message", message);
                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при отправке уведомления: {ex.Message}", "Ошибка",
                                MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
