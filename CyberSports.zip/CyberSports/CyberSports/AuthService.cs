﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace CyberSports
{
    public static class AuthService
    {
        public static int CurrentUserID { get; private set; }
        public static string CurrentUsername { get; private set; }
        public static bool IsAdmin { get; private set; }

        public static bool Login(string username, string password)
        {
            string hashedPassword = HashPassword(password);

            string query = @"
                SELECT u.UserID, u.Username, r.RoleName
                FROM Users u
                LEFT JOIN UserRoles ur ON u.UserID = ur.UserID
                LEFT JOIN Roles r ON ur.RoleID = r.RoleID
                WHERE u.Username = @Username AND u.PasswordHash = @PasswordHash AND u.IsActive = 1";

            using (SqlCommand cmd = new SqlCommand(query, App.Connection))
            {
                cmd.Parameters.AddWithValue("@Username", username);
                cmd.Parameters.AddWithValue("@PasswordHash", hashedPassword);

                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        CurrentUserID = (int)reader["UserID"];
                        CurrentUsername = reader["Username"].ToString();
                        IsAdmin = reader["RoleName"].ToString() == "Admin";
                        return true;
                    }
                }
            }
            return false;
        }

        public static void Logout()
        {
            CurrentUserID = 0;
            CurrentUsername = null;
            IsAdmin = false;
        }

        private static string HashPassword(string password)
        {
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
                StringBuilder builder = new StringBuilder();
                for (int i = 0; i < bytes.Length; i++)
                {
                    builder.Append(bytes[i].ToString("x2"));
                }
                return builder.ToString();
            }
        }

        public static bool HasPermission(string permission)
        {
            // Проверка прав пользователя
            string query = @"
                SELECT COUNT(*) 
                FROM UserRoles ur
                JOIN Roles r ON ur.RoleID = r.RoleID
                JOIN RolePermissions rp ON r.RoleID = rp.RoleID
                JOIN Permissions p ON rp.PermissionID = p.PermissionID
                WHERE ur.UserID = @UserID AND p.PermissionName = @Permission";

            using (SqlCommand cmd = new SqlCommand(query, App.Connection))
            {
                cmd.Parameters.AddWithValue("@UserID", CurrentUserID);
                cmd.Parameters.AddWithValue("@Permission", permission);
                return (int)cmd.ExecuteScalar() > 0;
            }
        }
    }
}
