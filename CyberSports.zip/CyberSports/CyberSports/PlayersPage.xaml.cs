﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CyberSports
{
    /// <summary>
    /// Логика взаимодействия для PlayersPage.xaml
    /// </summary>
    public partial class PlayersPage : Page  // Наследование от Page
    {
        public PlayersPage()
        {
            InitializeComponent();
            LoadTeams();
            LoadPlayers();
        }
        private void LoadTeams()
        {
            try
            {
                string query = "SELECT TeamID, TeamName FROM Teams WHERE IsActive = 1 ORDER BY TeamName";

                using (SqlCommand cmd = new SqlCommand(query, App.Connection))
                {
                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                    // Добавляем вариант "Все команды"
                    DataRow allTeamsRow = dt.NewRow();
                    allTeamsRow["TeamID"] = 0;
                    allTeamsRow["TeamName"] = "Все команды";
                    dt.Rows.InsertAt(allTeamsRow, 0);

                    cmbTeams.ItemsSource = dt.DefaultView;
                    cmbTeams.SelectedValue = 0;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке команд: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void LoadPlayers(int? teamId = null)
        {
            try
            {
                string query = @"
                    SELECT p.PlayerID, p.Nickname, t.TeamName, p.Position, p.IsCaptain, p.JoinDate
                    FROM Players p
                    LEFT JOIN Teams t ON p.TeamID = t.TeamID
                    WHERE (@TeamID = 0 OR p.TeamID = @TeamID OR (@TeamID IS NULL AND p.TeamID IS NULL))
                    ORDER BY t.TeamName, p.Nickname";

                using (SqlCommand cmd = new SqlCommand(query, App.Connection))
                {
                    cmd.Parameters.AddWithValue("@TeamID", teamId ?? 0);

                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                    PlayersGrid.ItemsSource = dt.DefaultView;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке игроков: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void AddPlayer_Click(object sender, RoutedEventArgs e)
        {
            PlayerEditWindow editWindow = new PlayerEditWindow();
            if (editWindow.ShowDialog() == true)
            {
                LoadPlayers();
            }
        }

        private void EditPlayer_Click(object sender, RoutedEventArgs e)
        {
            if (PlayersGrid.SelectedItem == null)
            {
                MessageBox.Show("Выберите игрока для редактирования", "Информация", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            DataRowView row = (DataRowView)PlayersGrid.SelectedItem;
            int playerId = (int)row["PlayerID"];

            PlayerEditWindow editWindow = new PlayerEditWindow(playerId);
            if (editWindow.ShowDialog() == true)
            {
                LoadPlayers();
            }
        }

        private void DeletePlayer_Click(object sender, RoutedEventArgs e)
        {
            if (PlayersGrid.SelectedItem == null)
            {
                MessageBox.Show("Выберите игрока для удаления", "Информация", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            DataRowView row = (DataRowView)PlayersGrid.SelectedItem;
            int playerId = (int)row["PlayerID"];
            string nickname = row["Nickname"].ToString();

            if (MessageBox.Show($"Вы уверены, что хотите удалить игрока '{nickname}'?",
                "Подтверждение удаления", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    string query = "DELETE FROM Players WHERE PlayerID = @PlayerID";
                    using (SqlCommand cmd = new SqlCommand(query, App.Connection))
                    {
                        cmd.Parameters.AddWithValue("@PlayerID", playerId);
                        cmd.ExecuteNonQuery();
                    }

                    MessageBox.Show("Игрок успешно удален", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                    LoadPlayers();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при удалении игрока: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void TeamFilterChanged(object sender, SelectionChangedEventArgs e)
        {
            if (cmbTeams.SelectedValue == null) return;

            int teamId = (int)cmbTeams.SelectedValue;
            LoadPlayers(teamId == 0 ? null : (int?)teamId);
        }

        private void SearchPlayers(object sender, System.Windows.Input.KeyEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtSearch.Text))
            {
                if (cmbTeams.SelectedValue != null)
                {
                    int teamId = (int)cmbTeams.SelectedValue;
                    LoadPlayers(teamId == 0 ? null : (int?)teamId);
                }
                return;
            }

            try
            {
                string query = @"
                    SELECT p.PlayerID, p.Nickname, t.TeamName, p.Position, p.IsCaptain, p.JoinDate
                    FROM Players p
                    LEFT JOIN Teams t ON p.TeamID = t.TeamID
                    WHERE p.Nickname LIKE @Search
                          AND (@TeamID = 0 OR p.TeamID = @TeamID OR (@TeamID IS NULL AND p.TeamID IS NULL))
                    ORDER BY t.TeamName, p.Nickname";

                using (SqlCommand cmd = new SqlCommand(query, App.Connection))
                {
                    cmd.Parameters.AddWithValue("@Search", $"%{txtSearch.Text}%");
                    cmd.Parameters.AddWithValue("@TeamID", cmbTeams.SelectedValue ?? 0);

                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                    PlayersGrid.ItemsSource = dt.DefaultView;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при поиске игроков: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
