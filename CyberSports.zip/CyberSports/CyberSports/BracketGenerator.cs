﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CyberSports
{
    public static class BracketGenerator
    {
        public static void GenerateSingleEliminationBracket(int tournamentId)
        {
            // Получаем список зарегистрированных команд
            List<int> teamIds = GetRegisteredTeams(tournamentId);

            if (teamIds.Count < 2)
            {
                throw new Exception("Для генерации сетки необходимо минимум 2 команды");
            }

            // Вычисляем количество раундов
            int rounds = (int)Math.Ceiling(Math.Log(teamIds.Count, 2));
            int matchesInFirstRound = (int)Math.Pow(2, rounds - 1);

            // Перемешиваем команды для случайного распределения
            Random rnd = new Random();
            teamIds = teamIds.OrderBy(x => rnd.Next()).ToList();

            // Добавляем "пустые" команды для полной сетки
            while (teamIds.Count < matchesInFirstRound * 2)
            {
                teamIds.Add(-1); // -1 означает "пропуск"
            }

            // Генерируем матчи
            GenerateMatches(tournamentId, teamIds, rounds, matchesInFirstRound);
        }

        private static List<int> GetRegisteredTeams(int tournamentId)
        {
            List<int> teamIds = new List<int>();

            string query = "SELECT TeamID FROM TournamentRegistrations WHERE TournamentID = @TournamentID AND IsApproved = 1";

            using (SqlCommand cmd = new SqlCommand(query, App.Connection))
            {
                cmd.Parameters.AddWithValue("@TournamentID", tournamentId);

                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        teamIds.Add((int)reader["TeamID"]);
                    }
                }
            }

            return teamIds;
        }

        private static void GenerateMatches(int tournamentId, List<int> teamIds, int rounds, int matchesInFirstRound)
        {
            // Удаляем старые матчи турнира
            DeleteExistingMatches(tournamentId);

            // Генерируем первый раунд
            List<MatchPair> currentMatches = new List<MatchPair>();

            for (int i = 0; i < matchesInFirstRound; i++)
            {
                int team1 = teamIds[i * 2];
                int team2 = teamIds[i * 2 + 1];

                if (team1 != -1 || team2 != -1) // Пропускаем матчи с двумя "пустыми" командами
                {
                    currentMatches.Add(new MatchPair
                    {
                        Team1 = team1 != -1 ? team1 : (int?)null,
                        Team2 = team2 != -1 ? team2 : (int?)null,
                        Round = 1,
                        MatchNumber = i + 1
                    });
                }
            }

            // Сохраняем матчи первого раунда
            SaveMatches(tournamentId, currentMatches);

            // Генерируем последующие раунды
            for (int round = 2; round <= rounds; round++)
            {
                int matchesInRound = matchesInFirstRound / (int)Math.Pow(2, round - 1);
                List<MatchPair> nextRoundMatches = new List<MatchPair>();

                for (int i = 0; i < matchesInRound; i++)
                {
                    nextRoundMatches.Add(new MatchPair
                    {
                        Team1 = null, // Победители будут определены позже
                        Team2 = null,
                        Round = round,
                        MatchNumber = i + 1
                    });
                }

                SaveMatches(tournamentId, nextRoundMatches);
                currentMatches = nextRoundMatches;
            }
        }

        private static void DeleteExistingMatches(int tournamentId)
        {
            string query = "DELETE FROM Matches WHERE TournamentID = @TournamentID";

            using (SqlCommand cmd = new SqlCommand(query, App.Connection))
            {
                cmd.Parameters.AddWithValue("@TournamentID", tournamentId);
                cmd.ExecuteNonQuery();
            }
        }

        private static void SaveMatches(int tournamentId, List<MatchPair> matches)
        {
            foreach (var match in matches)
            {
                string query = @"
                    INSERT INTO Matches 
                        (TournamentID, RoundNumber, MatchNumber, Status) 
                    VALUES 
                        (@TournamentID, @RoundNumber, @MatchNumber, 'Scheduled');
                    SELECT SCOPE_IDENTITY();";

                using (SqlCommand cmd = new SqlCommand(query, App.Connection))
                {
                    cmd.Parameters.AddWithValue("@TournamentID", tournamentId);
                    cmd.Parameters.AddWithValue("@RoundNumber", match.Round);
                    cmd.Parameters.AddWithValue("@MatchNumber", match.MatchNumber);

                    int matchId = Convert.ToInt32(cmd.ExecuteScalar());

                    // Сохраняем участников матча
                    SaveMatchParticipants(matchId, match.Team1, match.Team2);
                }
            }
        }

        private static void SaveMatchParticipants(int matchId, int? team1, int? team2)
        {
            if (team1.HasValue)
            {
                string query = "INSERT INTO MatchParticipants (MatchID, TeamID) VALUES (@MatchID, @TeamID)";
                using (SqlCommand cmd = new SqlCommand(query, App.Connection))
                {
                    cmd.Parameters.AddWithValue("@MatchID", matchId);
                    cmd.Parameters.AddWithValue("@TeamID", team1.Value);
                    cmd.ExecuteNonQuery();
                }
            }

            if (team2.HasValue)
            {
                string query = "INSERT INTO MatchParticipants (MatchID, TeamID) VALUES (@MatchID, @TeamID)";
                using (SqlCommand cmd = new SqlCommand(query, App.Connection))
                {
                    cmd.Parameters.AddWithValue("@MatchID", matchId);
                    cmd.Parameters.AddWithValue("@TeamID", team2.Value);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        private class MatchPair
        {
            public int? Team1 { get; set; }
            public int? Team2 { get; set; }
            public int Round { get; set; }
            public int MatchNumber { get; set; }
        }
    }
}
